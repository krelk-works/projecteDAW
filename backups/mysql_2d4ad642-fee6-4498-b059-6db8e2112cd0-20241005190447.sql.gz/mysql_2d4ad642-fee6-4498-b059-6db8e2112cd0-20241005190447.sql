-- MySQL dump 10.13  Distrib 8.0.22-13, for Linux (x86_64)
--
-- Host: localhost    Database: bbyirnoypbjzxaryzns9
-- ------------------------------------------------------
-- Server version	8.0.22-13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `Artwork`
--

DROP TABLE IF EXISTS `Artwork`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Artwork` (
  `Artwork_ID` int NOT NULL AUTO_INCREMENT,
  `ID_char` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ID_num1` int NOT NULL,
  `ID_num2` int DEFAULT NULL,
  `Artwork_name` varchar(300) NOT NULL,
  `Description` mediumtext,
  `Register_date` date NOT NULL DEFAULT (curdate()),
  `Creation_date` date DEFAULT NULL,
  `Conservation` varchar(300) DEFAULT NULL,
  `Material` varchar(300) DEFAULT NULL,
  `Cost` int DEFAULT NULL,
  `Amount` int NOT NULL,
  `Location_ID` int DEFAULT NULL,
  `Author_ID` int DEFAULT NULL,
  PRIMARY KEY (`Artwork_ID`),
  KEY `FK_Artwork_ID_Location` (`Location_ID`),
  KEY `FK_Artwork_ID_Author` (`Author_ID`),
  CONSTRAINT `FK_Artwork_ID_Author` FOREIGN KEY (`Author_ID`) REFERENCES `Author` (`Author_ID`),
  CONSTRAINT `FK_Artwork_ID_Location` FOREIGN KEY (`Location_ID`) REFERENCES `Location` (`Location_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Artwork`
--

LOCK TABLES `Artwork` WRITE;
/*!40000 ALTER TABLE `Artwork` DISABLE KEYS */;
INSERT INTO `Artwork` VALUES (97,'A',1,1,'Obra de Arte 1','Descripción de prueba 1','2024-10-01','2021-01-01','Bueno','Óleo sobre lienzo',1000,1,1,3),(98,'B',1,2,'Obra de Arte 2','Descripción de prueba 2','2024-10-01','2020-02-01','Muy bueno','Acrílico sobre tela',2000,2,1,3),(99,'C',1,3,'Obra de Arte Fenosa','Descripción de prueba siuu','2024-10-01','2019-03-01','Excelente','Escultura en mármol',3000,1,1,4),(100,'D',1,4,'Obra de Arte 4','Descripción de prueba 4','2024-10-01','2018-04-01','Regular','Grabado en madera',1500,1,1,3),(101,'E',1,5,'Obra de Arte 5','Descripción de prueba 5','2024-10-01','2017-05-01','Bueno','Fotografía',500,2,1,3),(102,'F',1,6,'Obra de Arte 6','Descripción de prueba 6','2024-10-01','2016-06-01','Excelente','Técnica mixta',1200,1,1,3),(103,'G',1,7,'Obra de Arte 7','Descripción de prueba 7','2024-10-01','2015-07-01','Bueno','Dibujo en papel',800,1,1,3),(104,'H',1,8,'Obra de Arte 8','Descripción de prueba 8','2024-10-01','2014-08-01','Muy bueno','Escultura en bronce',2500,1,1,3),(105,'I',1,9,'Obra de Arte 9','Descripción de prueba 9','2024-10-01','2013-09-01','Bueno','Pintura digital',1800,2,1,3),(106,'J',1,10,'Obra de Arte 10','Descripción de prueba 10','2024-10-01','2012-10-01','Excelente','Mosaico',2200,1,1,3),(107,'K',1,11,'Obra de Arte 11','Descripción de prueba 11','2024-10-01','2011-11-01','Regular','Acuarela',400,1,1,3),(108,'L',1,12,'Obra de Arte 12','Descripción de prueba 12','2024-10-01','2010-12-01','Bueno','Lápiz sobre papel',600,1,1,3),(109,'M',1,13,'Obra de Arte 13','Descripción de prueba 13','2024-10-01','2009-01-01','Muy bueno','Escultura en piedra',3200,1,1,3),(110,'N',1,14,'Obra de Arte 14','Descripción de prueba 14','2024-10-01','2008-02-01','Bueno','Dibujo en carbón',500,1,1,3),(111,'O',1,15,'Obra de Arte 15','Descripción de prueba 15','2024-10-01','2007-03-01','Excelente','Serigrafía',1300,1,1,3),(112,'P',1,16,'Obra de Arte 16','Descripción de prueba 16','2024-10-01','2006-04-01','Bueno','Óleo sobre lienzo',900,2,1,3),(113,'Q',1,17,'Obra de Arte 17','Descripción de prueba 17','2024-10-01','2005-05-01','Muy bueno','Acrílico sobre lienzo',2100,1,1,3),(114,'R',1,18,'Obra de Arte 18','Descripción de prueba 18','2024-10-01','2004-06-01','Regular','Fotografía en blanco y negro',300,1,1,3),(115,'S',1,19,'Obra de Arte 19','Descripción de prueba 19','2024-10-01','2003-07-01','Bueno','Impresión digital',1400,1,1,3),(116,'T',1,20,'Obra de Arte 20','Descripción de prueba 20','2024-10-01','2002-08-01','Excelente','Collage',2000,1,1,3),(117,'U',1,21,'Obra de Arte 21','Descripción de prueba 21','2024-10-01','2001-09-01','Muy bueno','Escultura en hierro',3500,1,1,3),(118,'V',1,22,'Obra de Arte 22','Descripción de prueba 22','2024-10-01','2000-10-01','Bueno','Técnica mixta',1800,1,1,3),(119,'W',1,23,'Obra de Arte 23','Descripción de prueba 23','2024-10-01','1999-11-01','Regular','Fotografía en color',700,2,1,3),(120,'X',1,24,'Obra de Arte 24','Descripción de prueba 24','2024-10-01','1998-12-01','Muy bueno','Grabado',2600,1,1,3),(121,'Y',1,25,'Obra de Arte 25','Descripción de prueba 25','2024-10-01','1997-01-01','Bueno','Pintura acrílica',1500,1,1,3),(122,'Z',1,26,'Obra de Arte 26','Descripción de prueba 26','2024-10-01','1996-02-01','Excelente','Dibujo en tinta',800,1,1,3),(123,'A',1,27,'Obra de Arte 27','Descripción de prueba 27','2024-10-01','1995-03-01','Regular','Escultura en arcilla',1700,1,1,3),(124,'B',1,28,'Obra de Arte 28','Descripción de prueba 28','2024-10-01','1994-04-01','Bueno','Técnica mixta',1100,1,1,3),(125,'C',1,29,'Obra de Arte 29','Descripción de prueba 29','2024-10-01','1993-05-01','Excelente','Dibujo en pastel',1300,1,1,3),(126,'D',1,30,'Obra de Arte 30','Descripción de prueba 30','2024-10-01','1992-06-01','Bueno','Óleo sobre tabla',1600,2,1,3),(127,'E',1,31,'Obra de Arte 31','Descripción de prueba 31','2024-10-01','1991-07-01','Muy bueno','Técnica mixta',2400,1,1,3),(128,'F',1,32,'Obra de Arte 32','Descripción de prueba 32','2024-10-01','1990-08-01','Bueno','Acrílico sobre lienzo',1200,1,1,3),(129,'G',1,33,'Obra de Arte 33','Descripción de prueba 33','2024-10-01','1989-09-01','Excelente','Pintura al óleo',2800,1,1,3),(130,'H',1,34,'Obra de Arte 34','Descripción de prueba 34','2024-10-01','1988-10-01','Regular','Fotografía',500,1,1,3),(131,'I',1,35,'Obra de Arte 35','Descripción de prueba 35','2024-10-01','1987-11-01','Bueno','Dibujo en carboncillo',900,1,1,3),(132,'J',1,36,'Obra de Arte 36','Descripción de prueba 36','2024-10-01','1986-12-01','Excelente','Pintura digital',3200,1,1,3),(133,'K',1,37,'Obra de Arte 37','Descripción de prueba 37','2024-10-01','1985-01-01','Muy bueno','Escultura en metal',5000,1,1,3),(134,'L',1,38,'Obra de Arte 38','Descripción de prueba 38','2024-10-01','1984-02-01','Bueno','Acuarela',1300,1,1,3),(135,'M',1,39,'Obra de Arte 39','Descripción de prueba 39','2024-10-01','1983-03-01','Regular','Dibujo en tinta',400,1,1,3),(136,'N',1,40,'Obra de Arte 40','Descripción de prueba 40','2024-10-01','1982-04-01','Excelente','Mosaico',2000,1,1,3);
/*!40000 ALTER TABLE `Artwork` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Author`
--

DROP TABLE IF EXISTS `Author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Author` (
  `Author_ID` int NOT NULL AUTO_INCREMENT,
  `Author_name` varchar(100) DEFAULT '',
  `Author_birthdate` date DEFAULT NULL,
  PRIMARY KEY (`Author_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Author`
--

LOCK TABLES `Author` WRITE;
/*!40000 ALTER TABLE `Author` DISABLE KEYS */;
INSERT INTO `Author` VALUES (3,'Apel·les Fenosa',NULL),(4,'Apel·les ',NULL);
/*!40000 ALTER TABLE `Author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cancels`
--

DROP TABLE IF EXISTS `Cancels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Cancels` (
  `Cancel_ID` int NOT NULL AUTO_INCREMENT,
  `Reason` mediumtext NOT NULL,
  `Authorised_worker_name` varchar(100) NOT NULL DEFAULT '',
  `Artwork_ID` int NOT NULL DEFAULT (0),
  PRIMARY KEY (`Cancel_ID`),
  KEY `FK_Cancels_Artwork` (`Artwork_ID`),
  CONSTRAINT `FK_Cancels_Artwork` FOREIGN KEY (`Artwork_ID`) REFERENCES `Artwork` (`Artwork_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cancels`
--

LOCK TABLES `Cancels` WRITE;
/*!40000 ALTER TABLE `Cancels` DISABLE KEYS */;
/*!40000 ALTER TABLE `Cancels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Images`
--

DROP TABLE IF EXISTS `Images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Images` (
  `Image_ID` int NOT NULL AUTO_INCREMENT,
  `URL` text NOT NULL,
  `Artwork_ID` int DEFAULT '0',
  PRIMARY KEY (`Image_ID`),
  KEY `FK_Images_Artwork` (`Artwork_ID`),
  CONSTRAINT `FK_Images_Artwork` FOREIGN KEY (`Artwork_ID`) REFERENCES `Artwork` (`Artwork_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Images`
--

LOCK TABLES `Images` WRITE;
/*!40000 ALTER TABLE `Images` DISABLE KEYS */;
INSERT INTO `Images` VALUES (1,'assets/img/example3.jpg',98),(2,'assets/img/example3.jpg',99),(3,'assets/img/example3.jpg',100),(4,'assets/img/example3.jpg',101),(5,'assets/img/example3.jpg',102),(6,'assets/img/example3.jpg',103),(7,'assets/img/example3.jpg',104),(8,'assets/img/example3.jpg',105),(9,'assets/img/example3.jpg',106),(10,'assets/img/example3.jpg',107),(11,'assets/img/example3.jpg',108),(12,'assets/img/example3.jpg',109),(13,'assets/img/example3.jpg',110),(14,'assets/img/example3.jpg',111),(15,'assets/img/example3.jpg',112),(16,'assets/img/example3.jpg',113),(17,'assets/img/example3.jpg',114),(18,'assets/img/example3.jpg',115),(19,'assets/img/example3.jpg',116),(20,'assets/img/example3.jpg',117),(21,'assets/img/example3.jpg',118),(22,'assets/img/example3.jpg',119),(23,'assets/img/example3.jpg',120),(24,'assets/img/example3.jpg',121),(25,'assets/img/example3.jpg',122),(26,'assets/img/example3.jpg',123),(27,'assets/img/example3.jpg',124),(28,'assets/img/example3.jpg',125),(29,'assets/img/example3.jpg',126),(30,'assets/img/example3.jpg',127),(31,'assets/img/example3.jpg',128),(32,'assets/img/example3.jpg',129),(33,'assets/img/example3.jpg',130),(34,'assets/img/example3.jpg',131),(35,'assets/img/example3.jpg',132),(36,'assets/img/example3.jpg',133),(37,'assets/img/example3.jpg',134),(38,'assets/img/example3.jpg',135),(39,'assets/img/example3.jpg',136);
/*!40000 ALTER TABLE `Images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Location`
--

DROP TABLE IF EXISTS `Location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Location` (
  `Location_ID` int NOT NULL AUTO_INCREMENT,
  `Location_name` varchar(100) NOT NULL,
  `Parent_ID` int DEFAULT NULL,
  PRIMARY KEY (`Location_ID`),
  KEY `FK_Location_Location` (`Parent_ID`),
  CONSTRAINT `FK_Location_Location` FOREIGN KEY (`Parent_ID`) REFERENCES `Location` (`Location_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Location`
--

LOCK TABLES `Location` WRITE;
/*!40000 ALTER TABLE `Location` DISABLE KEYS */;
INSERT INTO `Location` VALUES (1,'Planta 1',NULL);
/*!40000 ALTER TABLE `Location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Movements`
--

DROP TABLE IF EXISTS `Movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Movements` (
  `Movement_ID` int NOT NULL AUTO_INCREMENT,
  `Start_date` date NOT NULL,
  `End_date` date DEFAULT NULL,
  `Reason` mediumtext NOT NULL,
  `Artwork_ID` int NOT NULL,
  PRIMARY KEY (`Movement_ID`),
  KEY `FK_Movements_Artwork` (`Artwork_ID`),
  CONSTRAINT `FK_Movements_Artwork` FOREIGN KEY (`Artwork_ID`) REFERENCES `Artwork` (`Artwork_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Movements`
--

LOCK TABLES `Movements` WRITE;
/*!40000 ALTER TABLE `Movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `Movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Restoration`
--

DROP TABLE IF EXISTS `Restoration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Restoration` (
  `Restoration_ID` int NOT NULL AUTO_INCREMENT,
  `Start_Date` date NOT NULL,
  `End_Date` date DEFAULT NULL,
  `Reason` mediumtext NOT NULL,
  `Artwork_ID` int NOT NULL DEFAULT (0),
  PRIMARY KEY (`Restoration_ID`),
  KEY `FK_Restoration_Artwork` (`Artwork_ID`),
  CONSTRAINT `FK_Restoration_Artwork` FOREIGN KEY (`Artwork_ID`) REFERENCES `Artwork` (`Artwork_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Restoration`
--

LOCK TABLES `Restoration` WRITE;
/*!40000 ALTER TABLE `Restoration` DISABLE KEYS */;
/*!40000 ALTER TABLE `Restoration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `lastname` varchar(150) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `email` varchar(180) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` enum('admin','tecnic','convidat') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `profileimg` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'assets/img/defaultprofile.png',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin','Carla','Pérez Camacho','admin@admin.com','admin','assets/img/adminprofile.png'),(2,'test','test','Jose-Ignacio','García Jiménez','test@test.com','admin','assets/img/testingprofile.png'),(3,'tecnic','tecnic','Juan-Carlos','Martínez','tecnic@tecnic.com','tecnic','assets/img/defaultprofile.png'),(4,'convidat','convidat','Convidat','','convidat@convidat.com','convidat','assets/img/defaultprofile.png'),(55,'CarlosG','password123','Carlos','Garcia','carlos.garcia@example.com','admin','assets/img/defaultprofile.png'),(56,'MariaL','password123','Maria','Lopez','maria.lopez@example.com','tecnic','assets/img/defaultprofile.png'),(57,'JuanM','password123','Juan','Martinez','juan.martinez@example.com','convidat','assets/img/defaultprofile.png'),(58,'LuisH','password123','Luis','Hernandez','luis.hernandez@example.com','admin','assets/img/defaultprofile.png'),(59,'AnaG','password123','Ana','Gonzalez','ana.gonzalez@example.com','tecnic','assets/img/defaultprofile.png'),(60,'PabloD','password123','Pablo','Diaz','pablo.diaz@example.com','convidat','assets/img/defaultprofile.png'),(61,'SaraP','password123','Sara','Perez','sara.perez@example.com','admin','assets/img/defaultprofile.png'),(62,'JavierS','password123','Javier','Sanchez','javier.sanchez@example.com','tecnic','assets/img/defaultprofile.png'),(63,'CarmenR','password123','Carmen','Ramirez','carmen.ramirez@example.com','convidat','assets/img/defaultprofile.png'),(64,'AlbertoF','password123','Alberto','Flores','alberto.flores@example.com','admin','assets/img/defaultprofile.png'),(65,'EvaT','password123','Eva','Torres','eva.torres@example.com','tecnic','assets/img/defaultprofile.png'),(66,'VictorR','password123','Victor','Rivera','victor.rivera@example.com','convidat','assets/img/defaultprofile.png'),(67,'DanielaJ','password123','Daniela','Jimenez','daniela.jimenez@example.com','admin','assets/img/defaultprofile.png'),(68,'FranciscoM','password123','Francisco','Morales','francisco.morales@example.com','tecnic','assets/img/defaultprofile.png'),(69,'ClaraO','password123','Clara','Ortiz','clara.ortiz@example.com','convidat','assets/img/defaultprofile.png'),(70,'RaulC','password123','Raul','Castillo','raul.castillo@example.com','admin','assets/img/defaultprofile.png'),(71,'PatriciaG','password123','Patricia','Gil','patricia.gil@example.com','tecnic','assets/img/defaultprofile.png'),(72,'GabrielR','password123','Gabriel','Ramos','gabriel.ramos@example.com','convidat','assets/img/defaultprofile.png'),(73,'TeresaF','password123','Teresa','Fernandez','teresa.fernandez@example.com','admin','assets/img/defaultprofile.png'),(74,'AdrianR','password123','Adrian','Ruiz','adrian.ruiz@example.com','tecnic','assets/img/defaultprofile.png'),(75,'LorenaM','password123','Lorena','Mendoza','lorena.mendoza@example.com','convidat','assets/img/defaultprofile.png'),(76,'SergioV','password123','Sergio','Vega','sergio.vega@example.com','admin','assets/img/defaultprofile.png'),(77,'AliciaS','password123','Alicia','Santos','alicia.santos@example.com','tecnic','assets/img/defaultprofile.png'),(78,'FernandoC','password123','Fernando','Campos','fernando.campos@example.com','convidat','assets/img/defaultprofile.png'),(79,'IsabelR','password123','Isabel','Romero','isabel.romero@example.com','admin','assets/img/defaultprofile.png'),(80,'DiegoA','password123','Diego','Acosta','diego.acosta@example.com','tecnic','assets/img/defaultprofile.png'),(81,'JuliaF','password123','Julia','Ferrer','julia.ferrer@example.com','convidat','assets/img/defaultprofile.png'),(82,'JorgeN','password123','Jorge','Navarro','jorge.navarro@example.com','admin','assets/img/defaultprofile.png'),(83,'ElenaR','password123','Elena','Reyes','elena.reyes@example.com','tecnic','assets/img/defaultprofile.png'),(84,'AlfredoP','password123','Alfredo','Pena','alfredo.pena@example.com','convidat','assets/img/defaultprofile.png'),(85,'CristinaH','password123','Cristina','Herrera','cristina.herrera@example.com','admin','assets/img/defaultprofile.png'),(86,'RamonG','password123','Ramon','Garcia','ramon.garcia@example.com','tecnic','assets/img/defaultprofile.png'),(87,'MartaG','password123','Marta','Gutierrez','marta.gutierrez@example.com','convidat','assets/img/defaultprofile.png'),(88,'RicardoC','password123','Ricardo','Cruz','ricardo.cruz@example.com','admin','assets/img/defaultprofile.png'),(89,'SilviaL','password123','Silvia','Lopez','silvia.lopez@example.com','tecnic','assets/img/defaultprofile.png'),(90,'PedroS','password123','Pedro','Sanchez','pedro.sanchez@example.com','convidat','assets/img/defaultprofile.png'),(91,'BeatrizM','password123','Beatriz','Moreno','beatriz.moreno@example.com','admin','assets/img/defaultprofile.png'),(92,'EmilioM','password123','Emilio','Martinez','emilio.martinez@example.com','tecnic','assets/img/defaultprofile.png'),(93,'SusanaM','password123','Susana','Molina','susana.molina@example.com','convidat','assets/img/defaultprofile.png'),(94,'EduardoP','password123','Eduardo','Perez','eduardo.perez@example.com','admin','assets/img/defaultprofile.png'),(95,'PaulaS','password123','Paula','Suarez','paula.suarez@example.com','tecnic','assets/img/defaultprofile.png'),(96,'AntonioO','password123','Antonio','Ortega','antonio.ortega@example.com','convidat','assets/img/defaultprofile.png'),(97,'GloriaD','password123','Gloria','Delgado','gloria.delgado@example.com','admin','assets/img/defaultprofile.png'),(98,'LuisM','password123','Luis','Mendez','luis.mendez@example.com','tecnic','assets/img/defaultprofile.png'),(99,'RosaV','password123','Rosa','Vazquez','rosa.vazquez@example.com','convidat','assets/img/defaultprofile.png'),(100,'OscarC','password123','Oscar','Cano','oscar.cano@example.com','admin','assets/img/defaultprofile.png'),(101,'MonicaR','password123','Monica','Rios','monica.rios@example.com','tecnic','assets/img/defaultprofile.png'),(102,'FelipeN','password123','Felipe','Nuñez','felipe.nunez@example.com','convidat','assets/img/defaultprofile.png'),(103,'NataliaS','password123','Natalia','Sierra','natalia.sierra@example.com','admin','assets/img/defaultprofile.png'),(104,'HugoS','password123','Hugo','Salas','hugo.salas@example.com','tecnic','assets/img/defaultprofile.png'),(105,'aaa','aaa','aaa','aaa','aaa@gmail.com','tecnic','assets/img/defaultprofile.png'),(106,'elbicho','bicho','bicho','bicho','bicho@gmail.com','admin','assets/img/defaultprofile.png'),(107,'asasas','asassasa','dsfsagsdgvbsk','dfksdgnjsdng','vivaelbetis@fmail.com','convidat','assets/img/defaultprofile.png'),(108,'elbichin','bicho','bichooo','suuu','suu@gmail.com','admin','assets/img/bicho.png'),(109,'elbichin','bicho','bichooo','suuu','suu@gmail.com','admin','assets/img/bicho.png'),(110,'suu','suu','suu','suu','suus@gmail.com','admin','assets/img/'),(111,'bichin2','bichooo','hola','hola','hola@gmail.com','admin','assets/img/'),(112,'aa','gnsdgsdjgnsdj','ngkjdnbjdn','gdnjkdnsjg','fdjngfdj@gmail.com','admin','/assets/img/'),(113,'asas','asasasa','sasasas','sasa','asasasa@gmail.com','admin','assets/img/bicho.png'),(114,'siuuu','siuuuu','siuuu','siuuuu','siuu@gmail.com','admin','assets/img/bicho.png'),(115,'siuuu','siuuuu','siuuu','siuuuu','siuu@gmail.com','admin','assets/img/bicho.png'),(116,'siuuu','siuuuu','siuuu','siuuuu','siuu@gmail.com','admin','assets/img/bicho.png'),(117,'siuuu','siuuuu','siuuu','siuuuu','siuu@gmail.com','admin','assets/img/bicho.png'),(118,'siuuu','siuuuu','siuuu','siuuuu','siuu@gmail.com','admin','assets/img/bicho.png'),(119,'uj','bj','bj','b','bb@gmail.com','admin','assets/img/bicho.png'),(120,'uj','bj','bj','b','bb@gmail.com','admin','assets/img/bicho.png'),(121,'messi','messi','messi','messi','messi@gmail.com','admin','assets/img/messi.jpg'),(124,'prueba','prueba','prueba','prueba','prueba@gmail.com','tecnic','assets/img/bicho.png'),(125,'asasas','dsafasvs','kjnfjsdngsj','njfgnsdjgns','dnksng@gmail.com','admin','assets/img/bicho.png'),(126,'asasas','dsafasvs','kjnfjsdngsj','njfgnsdjgns','dnksng@gmail.com','admin','assets/img/bicho.png'),(127,'sfvsdgsg','dfhdfh','fdhfdh','gfqh','dgsdgh@gmail.com','admin','assets/img/bicho.png'),(128,'sfvsdgsg','asas','fdhfdh','gfqh','dgsdgh@gmail.com','admin','assets/img/bicho.png'),(129,'ssss','sss','fdhfdh','gfqh','dgsdgh@gmail.com','admin','assets/img/bicho.png'),(130,'asasa','asasa','sasas','asasas','asaasasasa@gmail.com','admin','assets/img/messi.jpg'),(131,'asasa','asasa','sasas','asasas','asaasasasa@gmail.com','admin','assets/img/messi.jpg'),(132,'asasa','asasa','sasas','asasas','asaasasasa@gmail.com','admin','assets/img/messi.jpg'),(133,'as','asasasa','sasasasa','sasasasasa','pooo@gmail.com','tecnic','assets/img/messi.jpg'),(134,'as','asasasa','sasasasa','sasasasasa','pooo@gmail.com','tecnic','assets/img/messi.jpg'),(135,'as','asasasa','sasasasa','sasasasasa','pooo@gmail.com','tecnic','assets/img/messi.jpg'),(136,'siuuu','sdbfsabghsbg','bnfdjbnsjb','hdnjsubs','jdnjsd@gmail.com','admin','assets/img/messi.jpg'),(137,'apapfk','mksdkgmsk','fgkmgk','fmgm','mkghm@gmail.com','admin','assets/img/messi.jpg'),(138,'apapfk','mksdkgmsk','fgkmgk','fmgm','mkghm@gmail.com','admin','assets/img/messi.jpg'),(139,'afafg','dsgsdgs','gfdgsdfg','dgsgs','gfgd@gmail.com','admin','assets/img/bicho.png'),(140,'asas','sasasa','sasasa','sasasasa','sasa@gmail.com','admin','assets/img/bicho.png'),(141,'sfgdfg','fgfg','fdgdsfg','dfgfdg','dfgfgd@a.a','convidat','assets/img/Captura de pantalla de 2024-10-02 08-43-55.png'),(142,'dgdg','dgfdg','dg','gd','a@a.a','convidat','assets/img/Captura de pantalla de 2024-10-02 08-43-55.png'),(143,'.','aaa','Olga','Apruebanos','El@Trabajo.Porfa','admin','assets/img/Captura de pantalla de 2024-10-02 08-43-55.png'),(144,'asfagasg','sgdsgdsg','dsgsdg','dsgsdgsdg','naa@gmail.com','admin','assets/img/messi.jpg'),(145,'asasasa','sasasa','sasasa','sasasa','sasasasasasasa@gmail.com','admin','assets/img/messi.jpg'),(146,'asasasrrr','asasasarr','asasasarr','sasasarrr','asasiuuu@gmail.com','admin','assets/img/bicho.png'),(147,'vivaelbetis','sevilla','sevilla','sevilla','sevillista@gmail.com','admin','assets/img/bicho.png'),(148,'pruebas','pruebas','pruebas','pruebas','pruebas@gmail.com','admin','assets/img/messi.jpg');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-05 19:04:55
