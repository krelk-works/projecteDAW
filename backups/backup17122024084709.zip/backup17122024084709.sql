-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: bbyirnoypbjzxaryzns9-mysql.services.clever-cloud.com    Database: bbyirnoypbjzxaryzns9
-- ------------------------------------------------------
-- Server version	8.0.22-13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `bbyirnoypbjzxaryzns9`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `bbyirnoypbjzxaryzns9` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `bbyirnoypbjzxaryzns9`;

--
-- Table structure for table `artworks`
--

DROP TABLE IF EXISTS `artworks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artworks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_letter` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `id_num1` int NOT NULL,
  `id_num2` int DEFAULT NULL,
  `museumname` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `name` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci,
  `provenancecollection` text,
  `register_date` date NOT NULL DEFAULT (curdate()),
  `creation_date` date DEFAULT NULL,
  `height` int DEFAULT NULL,
  `width` int DEFAULT NULL,
  `depth` int DEFAULT NULL,
  `title` text,
  `originplace` text,
  `executionplace` text,
  `triage` text,
  `otheridnumbers` text,
  `cost` int DEFAULT NULL,
  `amount` int NOT NULL,
  `history` longtext CHARACTER SET utf8 COLLATE utf8_general_ci,
  `location` int DEFAULT NULL,
  `author` int DEFAULT NULL,
  `material` int DEFAULT NULL,
  `conservationstatus` int DEFAULT NULL,
  `datation` int DEFAULT NULL,
  `entry` int DEFAULT NULL,
  `genericclassification` int DEFAULT NULL,
  `materialgettycode` int DEFAULT NULL,
  `tecnique` int DEFAULT NULL,
  `tecniquegettycode` int DEFAULT NULL,
  `image` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `canceled` tinyint DEFAULT NULL,
  `bibliography` longtext,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Artwork_ID_Location` (`location`) USING BTREE,
  KEY `FK_Artwork_ID_Author` (`author`) USING BTREE,
  KEY `Material_ID` (`material`) USING BTREE,
  KEY `FK_artworks_conservationstatus` (`conservationstatus`),
  KEY `FK_artworks_datations` (`datation`),
  KEY `entry` (`entry`),
  KEY `FK_artworks_materialgettycodes` (`materialgettycode`),
  KEY `FK_artworks_tecniques` (`tecnique`),
  KEY `FK_artworks_tecniquegettycodes` (`tecniquegettycode`),
  KEY `FK_artworks_genericclassifications` (`genericclassification`) USING BTREE,
  CONSTRAINT `entry` FOREIGN KEY (`entry`) REFERENCES `entry` (`id`),
  CONSTRAINT `FK_3` FOREIGN KEY (`material`) REFERENCES `materials` (`id`),
  CONSTRAINT `FK_Artwork_ID_Author` FOREIGN KEY (`author`) REFERENCES `authors` (`id`),
  CONSTRAINT `FK_Artwork_ID_Location` FOREIGN KEY (`location`) REFERENCES `locations` (`id`),
  CONSTRAINT `FK_artworks_conservationstatus` FOREIGN KEY (`conservationstatus`) REFERENCES `conservationstatus` (`id`),
  CONSTRAINT `FK_artworks_datations` FOREIGN KEY (`datation`) REFERENCES `datations` (`id`),
  CONSTRAINT `FK_artworks_genericclassifications` FOREIGN KEY (`genericclassification`) REFERENCES `genericclassifications` (`id`),
  CONSTRAINT `FK_artworks_materialgettycodes` FOREIGN KEY (`materialgettycode`) REFERENCES `materialgettycodes` (`id`),
  CONSTRAINT `FK_artworks_tecniquegettycodes` FOREIGN KEY (`tecniquegettycode`) REFERENCES `tecniquegettycodes` (`id`),
  CONSTRAINT `FK_artworks_tecniques` FOREIGN KEY (`tecnique`) REFERENCES `tecniques` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=365 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artworks`
--

LOCK TABLES `artworks` WRITE;
/*!40000 ALTER TABLE `artworks` DISABLE KEYS */;
INSERT INTO `artworks` VALUES (342,'A',1,5,NULL,'El bon temps perseguint la tempesta','El bon temps perseguint la tempesta és una escultura emblemàtica d\'Apel·les Fenosa que simbolitza l’esperança i el triomf de la llum sobre la foscor. Aquesta obra representa un personatge al·legòric, sovint interpretat com una figura humana amb trets dinàmics, que sembla avançar amb determinació i serenitat. Al seu darrere, una representació subtil de formes arremolinades evoca el rastre de la tempesta que deixa enrere.\r\n\r\nLa peça, fidel al llenguatge artístic de Fenosa, destaca per la seva sensibilitat poètica i l\'ús magistral de les textures. L\'escultor utilitza el contrast entre superfícies llises i rugoses per reforçar la narrativa, creant un diàleg entre la calma i la turbulència. El moviment suggerit en les formes transmet la idea de canvi i superació, un tema recurrent en l\'obra de Fenosa, que sovint buscava reflectir les lluites i les esperances humanes.\r\n\r\nRealitzada principalment en bronze, aquesta escultura combina la força i la lleugeresa, una característica distintiva de Fenosa, que preferia deixar espai a la interpretació del públic. \"El bon temps perseguint la tempesta\" es pot entendre com una metàfora de l’experiència humana, marcada per moments de dificultat i superació.\r\n\r\nActualment, aquesta obra és considerada una de les peces més destacades del catàleg de Fenosa i es conserva al Museu Apel·les Fenosa del Vendrell, on forma part de la col·lecció permanent. També ha estat exposada en nombroses mostres internacionals, on ha estat reconeguda pel seu missatge universal i la seva impactant força visual.','Col·lecció Apel·les Fenosa','2024-11-16','1978-01-01',30,30,40,'El bon temps perseguint la tempesta','Museu Apel·les Fenosa','Museu Apel·les Fenosa','Sense tiratge',NULL,200000,1,'L’obra El bon temps perseguint la tempesta es va concebre en un dels moments més reflexius de la carrera d’Apel·les Fenosa, al voltant dels anys 50, després del seu retorn a França després de la Segona Guerra Mundial. Fenosa, que havia estat profundament afectat pels conflictes socials i polítics del seu temps, va canalitzar aquestes experiències en una obra que simbolitza la resiliència i l’esperança davant l’adversitat.\r\n\r\nLa peça es caracteritza per la seva al·legoria poètica, representant la lluita constant entre les forces de la destrucció i la renovació. Fenosa va descriure aquesta obra com una metàfora visual del triomf de la calma, la llum i l’harmonia sobre les turbulències de la vida. Les formes dinàmiques de l’escultura suggereixen un moviment cap a un futur més esperançador, mentre que els elements arremolinats al·ludeixen a les ombres d’un passat tempestuós.\r\n\r\nLa primera exposició de l’obra va tenir lloc a París en una mostra col·lectiva d’artistes exiliats catalans, organitzada per les Galeries Maeght. Aquesta presentació va consolidar Fenosa com una figura clau en l’art europeu de postguerra. \"El bon temps perseguint la tempesta\" va ser molt ben rebuda per la crítica, que va destacar la seva capacitat per transmetre emocions universals amb una senzillesa formal impressionant.\r\n\r\nDesprés de la seva exhibició a França, l’escultura va formar part d’una col·lecció privada fins que va ser adquirida per la Fundació Apel·les Fenosa al Vendrell. Allí es conserva com a part de la col·lecció permanent, on continua sent una de les peces més admirades pel seu significat profund i per la seva rellevància històrica i artística.\r\n\r\nAl llarg dels anys, El bon temps perseguint la tempesta ha estat exposada en nombrosos museus i galeries internacionals, incloent-hi el Museu Nacional d’Art de Catalunya (MNAC) i el Museu de l’Hermitage. L’obra ha esdevingut un símbol de superació i esperança, mantenint el seu missatge universal vigent per a generacions futures.',10,3,1,1,359,13,1,1,1,NULL,'uploads/1731780708_2171.jpg',1,NULL),(343,NULL,2,NULL,NULL,'Millepertius','Millepertius és una escultura de bronze creada per Apel·les Fenosa que destaca per la seva abstracció poètica i la seva connexió amb la natura. L’obra representa una figura vegetal estilitzada que sembla emergir del terra, com un homenatge a la persistència i la força vital de les plantes. El títol de l’escultura fa referència al hipèric perforat (millepertuis en francès), una planta coneguda per les seves propietats curatives, que simbolitza la regeneració i l’esperança.\r\n\r\nL’obra és un exemple clar de la relació íntima que Fenosa mantenia amb la natura, una temàtica recurrent al llarg de la seva carrera. Les línies ascendents i les superfícies texturades suggereixen el creixement, mentre que la base sòlida connecta l’escultura amb la terra. La senzillesa formal de l’obra amaga una complexitat simbòlica que convida a la reflexió sobre la connexió entre l’ésser humà i el món natural.','Col·lecció Apel·les Fenosa','2024-11-16','1962-01-01',30,30,10,'Millepertius','Museu Apel·les Fenosa','Museu Apel·les Fenosa','Sense tiratge',NULL,250000,1,'Millepertius va ser concebuda durant els anys 60, una etapa en què Apel·les Fenosa estava profundament influenciat per la seva estada a Vallauris, al sud de França. En aquest període, l’artista va establir una estreta relació amb el paisatge mediterrani i amb el seu entorn natural, que es va convertir en una font d’inspiració constant per a la seva obra escultòrica.\r\n\r\nFenosa va declarar que aquesta peça era un homenatge a la resiliència de la natura, un tema que va explorar en diverses obres. L\'escultura, segons ell mateix, representa \"la força silenciosa de la natura que s’alça malgrat les adversitats\". Aquesta obra va ser presentada per primera vegada a París, en una exposició dedicada a la seva connexió amb la natura.\r\n\r\nPosteriorment, \"Millepertius\" va formar part de diverses exposicions internacionals, incloent-hi la mostra \"L’ànima de la natura\" al Museu Apel·les Fenosa del Vendrell, on actualment es troba. La peça ha estat reconeguda com una de les seves escultures més simbòliques per la seva capacitat de transmetre un missatge universal a través d’una forma orgànica i evocadora.',10,3,1,1,359,13,1,1,1,NULL,'uploads/1731782316_4454.jpg',1,NULL),(357,'C',2,2,NULL,'La Dernière ','Esta pieza adquiere con el tiempo un nuevo sentido. La representación cosmológica de mitos y elementos va deviniendo abstracta. La espiritualidad y la transparencia del gesto sutil inherente a su trabajo se hace cada vez más evidente en sus últimas obras. Así como Henri Moore afirmaba que «la figura humana es la base de toda mi escultura, y esa para mi es el desnudo femenino» (Catálogo de la Fundación Miró 1982, p. 51), en Fenosa algunos de sus hallazgos formales y técnicos se evidencian años después despojando su obra de accesorios. El poso de sus investigaciones sobre la historia del arte, del arte primitivo al etrusco y toda la influencia oriental especialmente japonesa, desembocan en la depurada síntesis de las piezas de su último periodo. Estas obras no llegaron a ser fundidas a gran escala.','Buenos Dias','2024-11-19','2024-11-19',14,5,4,'La Dernière ','Mi casa','Si','Tambien',NULL,150000,1,'\r\n\r\nEsta pieza adquiere con el tiempo un nuevo sentido. La representación cosmológica de mitos y elementos va deviniendo abstracta. La espiritualidad y la transparencia del gesto sutil inherente a su trabajo se hace cada vez más evidente en sus últimas obras. Así como Henri Moore afirmaba que «la figura humana es la base de toda mi escultura, y esa para mi es el desnudo femenino» (Catálogo de la Fundación Miró 1982, p. 51), en Fenosa algunos de sus hallazgos formales y técnicos se evidencian años después despojando su obra de accesorios. El poso de sus investigaciones sobre la historia del arte, del arte primitivo al etrusco y toda la influencia oriental especialmente japonesa, desembocan en la depurada síntesis de las piezas de su último periodo. Estas obras no llegaron a ser fundidas a gran escala.\r\n\r\n \r\n\r\n«Si pudiera hacer una escultura sin materia, sería un hombre feliz». Apel·les Fenosa. Propos d´atelier.  Tillier. Bertrand (edi) Creil Editions Dumerchez 1995, 2e édition, Cognac. Le temps qu´il fait, 1997, p. 90\r\n',10,3,1,5,307,16,1,1,1,NULL,'uploads/1732002944_4402.jpg',1,NULL),(360,'I',1,1,NULL,'Orlando furioso','El gran volumen de esta pieza permite constatar toda una serie de decisiones técnicas y de contenido transmitiendo la fortaleza y fragilidad de la épica de la derrota, pero también de la esperanza. La obra igualmente evidencia la erudición de Fenosa, quien esta vez se centra en otro de los grandes mitos literarios, el Orlando furioso, cuyo relato le llevaba fascinando desde los años cuarenta. Referido en Francia como Roland furieux (siglo XI), el personaje fue fuente de inspiración para el autor de este poema épico fantástico, Ludovico Ariosto, publicado en 1532 (Fenosa, gran bibliófilo, conservaba una edición de 1773).','Orlando Furioso','2024-11-20','2024-11-20',235,85,230,'Orlando furioso','Apel·les Fenosa','Barcelona','Preparació per a una exposició temporal',NULL,100000,1,'\r\n\r\nEl gran volumen de esta pieza permite constatar toda una serie de decisiones técnicas y de contenido transmitiendo la fortaleza y fragilidad de la épica de la derrota, pero también de la esperanza. La obra igualmente evidencia la erudición de Fenosa, quien esta vez se centra en otro de los grandes mitos literarios, el Orlando furioso, cuyo relato le llevaba fascinando desde los años cuarenta. Referido en Francia como Roland furieux (siglo XI), el personaje fue fuente de inspiración para el autor de este poema épico fantástico, Ludovico Ariosto, publicado en 1532 (Fenosa, gran bibliófilo, conservaba una edición de 1773).\r\n\r\nEn una entrevista en 1971, Fenosa dirá: «Creo en la libertad, la dicha, la bondad, la perfección… La vida es una búsqueda continua de todas estas cosas. En mi opinión, el Orlando furioso es el mejor ejemplo de fidelidad que se puede encontrar. Persigue la idea de su amante, aunque pase junto a ella sin reconocerla». Orlando, errante y enloquecido pasa por una playa de Tarragona, hecho que no deja de conmover a Fenosa por su sentido y su localización tal y como señala Jean Leymarie en el catálogo editado por Skira\r\n\r\nFenosa volverá en cuatro ocasiones a este tema entre 1947 y 1971-73 en diferentes escalas.\r\n\r\nLa pieza monumental se encuentra en el jardín del Museo de Escultura de Leganés (Madrid) y se instaló en el complejo Antigone en Montpellier. Igualmente forma parte del conjunto de esculturas instaladas en el jardín de la Fundación Apel·les Fenosa en El Vendrell.\r\n',10,3,1,6,305,11,1,1,1,NULL,'uploads/1732087839_3687.jpg',NULL,NULL),(361,NULL,3,NULL,NULL,'Gran tête de Paul Éluard','La relación entre Fenosa y Paul Éluard (1895 -1952) trascendía lo intelectual de la conexión con otros poetas para evidenciar la complicidad paternofilial entre ambos creadores. Así se muestra en un escrito firmado por Éluard: «Pour Fenosa, de son père. Paul Éluard».  Existe en la Fundación un completo epistolario y numerosos testimonios documentales de la correspondencia entre ambos.','Gran tête de Paul Éluard','2024-11-20','2024-11-20',39,27,29,'Gran tête de Paul Éluard','Apel·les Fenosa','Lleida','Arribada d’una col·lecció donada al museu',NULL,80000,1,'\r\n\r\nLa relación entre Fenosa y Paul Éluard (1895 -1952) trascendía lo intelectual de la conexión con otros poetas para evidenciar la complicidad paternofilial entre ambos creadores. Así se muestra en un escrito firmado por Éluard: «Pour Fenosa, de son père. Paul Éluard».  Existe en la Fundación un completo epistolario y numerosos testimonios documentales de la correspondencia entre ambos.\r\n\r\nAlejado de las nuevas corrientes surrealistas o de la experimentación de las vanguardias históricas, la trayectoria de Fenosa respecto a los grupos de vanguardia era totalmente independiente, indagando en su propio lenguaje y peculiar universo creativo.\r\n\r\nRealizó los retratos de Paul y Nusch Éluard (1942), y después concibe un segundo retrato del poeta ya en grandes dimensiones, en la línea de sus primeras obras que dotaban a la cabeza de una proporción figurativa o a mayor escala. Las sesiones de posado y modelado se desarrollaron durante el mes de febrero. Con el prematuro fallecimiento de Nush, Éluard decide casarse tras una estancia en México con Dominique. Igualmente, los Fenosa desarrollaron una intensa relación viajando y realizando excursiones juntos a ellos, algo que solo se interrumpió con la muerte del poeta en 1952. Con todo, Cécile Éluard, hija de Paul y Gala -quien ya convivía con Dalí desentendiéndose de ella-, fue amiga incondicional de Apel·les y Nicole. Cécile Éluard llegó a El Vendrell en 1963 con su nuevo marido, Robert Valette, siendo una de las personas próximas a todo el proyecto de la Casa del Portal del Pardo.\r\n',10,3,1,1,300,11,1,1,1,NULL,'uploads/1732088333_1668.jpg',NULL,NULL),(362,'E',1,4,NULL,'Monument als màrtirs d\'Oradour','Desde el año 1999, se encuentra en Limoges en la Carretera d´Oradour/carrefour del Boulevar exterior, y desde 2011 en el Parque de los pueblos de Europa en Gernika.','Monument als màrtirs d\'Oradour','2024-11-20','2024-11-20',118,35,30,'Monument als màrtirs d\'Oradour','Apel·les Fenosa','Alicant ','Arribada d’una col·lecció donada al museu',NULL,120000,1,'\r\n\r\nLa maqueta concebida para el denominado Monument aux Martyrs d’Oradour-sur-Glane  muestra algunos detalles diferentes a la pieza final definitiva, lo cual evidencia la complejidad del proceso y su ubicación definitiva. La obra alude de forma directa a una de las mayores tragedias de la Segunda Guerra Mundial, la masacre de civiles en Oradour-sur-Glane cuando el 10 de junio de 1944 las tropas alemanas de las SS  incendiaron la urbe sacrificando de manera programada a las mujeres y niños en la iglesia y  a los hombres en las granjas y garajes. En ese periodo de la ocupación alemana, Fenosa residió con la familia de Laurent y Renée d´Albis en la localidad próxima de Jouxtens, una casa donde los alemanes firmaron su rendición local el 21 de agosto de 1944.  Los soldados de la F.F.I de la Resistencia encargaron a Fenosa el monumento conmemorativo de la tragedia. La versión definitiva de la obra en yeso fue expuesta en el Salon des Surindépendants en 1945. Aunque fue una obra defendida por intelectuales como Jean Genet o Jean Cassou, resultó molesta al obispo de la diócesis por representar a una mujer desnuda embarazada\r\n\r\nDesde el año 1999, se encuentra en Limoges en la Carretera d´Oradour/carrefour del Boulevar exterior, y desde 2011 en el Parque de los pueblos de Europa en Gernika.\r\n\r\nExiste numerosa bibliografía al respecto. La más específica es de Tillier, Bertrand: Un sculpteur à Oradour-sur-Glane. Fenosa, la Statue et les Ruines, El Vendrell: Fundació Fenosa, 2020\r\n',10,3,1,3,300,11,1,1,1,NULL,'uploads/1732088841_1306.jpg',NULL,NULL),(363,NULL,4,NULL,NULL,'Metamorphose 63',' trata de una pieza clave que evidencia esta eclosión de hibridaciones, resoluciones, formas y contenidos. Francis Ponge ha comparado esa obra con la Victoria de Samotracia: « una bella y gran Victoria, pero ya decapitada como la que tiembla en la puerta de Daru». ',' Metamorphose 63','2024-11-20','2024-11-20',165,64,44,'Metamorphose 63','Apel·les Fenosa',' El Vendrell','Preparació per a una exposició temporal',NULL,120000,1,'Muchas de las series de Fenosa son trabajos en proceso que van desarrollándose durante años perfilando y ajustando los mismos temas pero de diferentes formas. La serie de Metamorphose precisamente corresponde a esta genealogía de obras que van evolucionando a través del tiempo. Esta pieza monumental es la intermedia entre una investigación emprendida en 1962 (Métamorphose 62) y otra tercera pieza que oscila sobre lo femenino y lo vegetal (Métamorphose 64). Se trata de un paso entre la constitución de elementos de carácter orgánico que se transmutan en figuras humanas sugeridas y diferentes elementos naturales que irán confluyendo hacia formas cada vez mas abstractas. Se trata de una pieza clave que evidencia esta eclosión de hibridaciones, resoluciones, formas y contenidos. Francis Ponge ha comparado esa obra con la Victoria de Samotracia: « una bella y gran Victoria, pero ya decapitada como la que tiembla en la puerta de Daru». La versión anterior, Metamorphose 62 formó parte de la película dirigida por Philippe Garrel, Le vent de  la nuit (1999).',10,3,1,3,304,13,1,1,1,NULL,'uploads/1732089212_7445.jpg',NULL,NULL);
/*!40000 ALTER TABLE `artworks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '',
  `birthdate` date DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (3,'Apel·les Fenosa',NULL,1),(14,'Manolo Hugué',NULL,1),(15,'Pau Gargallo',NULL,1),(16,'Juli González',NULL,1),(17,'Aristide Maillol',NULL,1),(18,'Henri Laurens',NULL,1),(19,'Joan Miró',NULL,1),(20,'Eduardo Chillida',NULL,1),(21,'Constantin Brâncuși',NULL,1),(22,'Eusebio Sempere',NULL,1),(23,'Giacomo Manzù',NULL,1);
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cancelcauses`
--

DROP TABLE IF EXISTS `cancelcauses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cancelcauses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancelcauses`
--

LOCK TABLES `cancelcauses` WRITE;
/*!40000 ALTER TABLE `cancelcauses` DISABLE KEYS */;
INSERT INTO `cancelcauses` VALUES (1,'Confiscació',1),(2,'Destrucció',1),(3,'Estat de conservació molt deficient',1),(4,'Manteniment i restauració onerós',1),(5,'Pèrdua',1),(6,'Robatori',1),(7,'Successió interadministrativa',1),(8,'Valor patrimonial insuficient',1);
/*!40000 ALTER TABLE `cancelcauses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cancels`
--

DROP TABLE IF EXISTS `cancels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cancels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cancelcause` int NOT NULL DEFAULT '0',
  `authorised_worker_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `artwork` int NOT NULL DEFAULT '0',
  `description` longtext,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Cancels_Artwork` (`artwork`) USING BTREE,
  KEY `FK_cancels_cancelcauses` (`cancelcause`) USING BTREE,
  CONSTRAINT `FK_cancels_cancelcauses` FOREIGN KEY (`cancelcause`) REFERENCES `cancelcauses` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancels`
--

LOCK TABLES `cancels` WRITE;
/*!40000 ALTER TABLE `cancels` DISABLE KEYS */;
INSERT INTO `cancels` VALUES (1,2,'El admin',360,'aqui va la rao de baixa de l\'obra. es podrà introduir al panell de fitxes al donar de baixa una obra');
/*!40000 ALTER TABLE `cancels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conservationstatus`
--

DROP TABLE IF EXISTS `conservationstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conservationstatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conservationstatus`
--

LOCK TABLES `conservationstatus` WRITE;
/*!40000 ALTER TABLE `conservationstatus` DISABLE KEYS */;
INSERT INTO `conservationstatus` VALUES (1,'Bo',1),(2,'Dolent',1),(3,'Excel·lent',1),(4,'Indeterminat',1),(5,'desconeguda',1),(6,'Regular',1);
/*!40000 ALTER TABLE `conservationstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datations`
--

DROP TABLE IF EXISTS `datations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL,
  `start_date` int DEFAULT '0',
  `end_date` int DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=370 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datations`
--

LOCK TABLES `datations` WRITE;
/*!40000 ALTER TABLE `datations` DISABLE KEYS */;
INSERT INTO `datations` VALUES (1,'segle IV ante',-400,-301,1),(2,'primera meitat segle IV ante',-400,-351,1),(3,'primer quart segle IV ante',-400,-376,1),(4,'segon quart segle IV ante',-375,-351,1),(5,'segona meitat segle IV ante',-350,-301,1),(6,'tercer quart segle IV ante',-350,-326,1),(7,'últim quart segle IV ante',-325,-301,1),(8,'segle III ante',-300,-201,1),(9,'primera meitat segle III ante',-300,-251,1),(10,'primer quart segle III ante',-300,-276,1),(11,'segon quart segle III ante',-275,-251,1),(12,'segona meitat segle III ante',-250,-201,1),(13,'tercer quart segle III ante',-250,-226,1),(14,'últim quart segle III ante',-225,-201,1),(15,'segle II ante',-200,-101,1),(16,'primera meitat segle II ante',-200,-151,1),(17,'primer quart segle II ante',-200,-176,1),(18,'segon quart segle II ante',-175,-151,1),(19,'segona meitat segle II ante',-150,-101,1),(20,'tercer quart segle II ante',-150,-126,1),(21,'últim quart segle II ante',-125,-101,1),(22,'segle I ante',-100,-1,1),(23,'primera meitat segle I ante',-100,-51,1),(24,'primer quart segle I ante',-100,-76,1),(25,'segon quart segle I ante',-75,-51,1),(26,'segona meitat segle I ante',-50,-1,1),(27,'tercer quart segle I ante',-50,-26,1),(28,'últim quart segle I ante',-25,-1,1),(29,'segle I',1,100,1),(30,'primera meitat segle I',1,50,1),(31,'primer quart segle I',1,25,1),(32,'segon quart segle I',26,50,1),(33,'segona meitat segle I',51,100,1),(34,'tercer quart segle I',51,75,1),(35,'últim quart segle I',76,100,1),(36,'segle II',101,200,1),(37,'primera meitat segle II',101,150,1),(38,'primer quart segle II',101,125,1),(39,'segon quart segle II',126,150,1),(40,'segona meitat segle II',151,200,1),(41,'tercer quart segle II',151,175,1),(42,'últim quart segle II',176,200,1),(43,'segle III',201,300,1),(44,'primera meitat segle III',201,250,1),(45,'primer quart segle III',201,225,1),(46,'segon quart segle III',226,250,1),(47,'segona meitat segle III',251,300,1),(48,'tercer quart segle III',251,275,1),(49,'últim quart segle III',276,300,1),(50,'segle IV',301,400,1),(51,'primera meitat segle IV',301,350,1),(52,'primer quart segle IV',301,325,1),(53,'segon quart segle IV',326,350,1),(54,'segona meitat segle IV',351,400,1),(55,'tercer quart segle IV',351,375,1),(56,'últim quart segle IV',376,400,1),(57,'segle V',401,500,1),(58,'primera meitat segle V',401,450,1),(59,'primer quart segle V',401,425,1),(60,'segon quart segle V',426,450,1),(61,'segona meitat segle V',451,500,1),(62,'tercer quart segle V',451,475,1),(63,'últim quart segle V',476,500,1),(64,'segle VI',501,600,1),(65,'primera meitat segle VI',501,550,1),(66,'primer quart segle VI',501,525,1),(67,'segon quart segle VI',526,550,1),(68,'segona meitat segle VI',551,600,1),(69,'tercer quart segle VI',551,575,1),(70,'últim quart segle VI',576,600,1),(71,'segle VII',601,700,1),(72,'primera meitat segle VII',601,650,1),(73,'primer quart segle VII',601,625,1),(74,'segon quart segle VII',626,650,1),(75,'segona meitat segle VII',651,700,1),(76,'tercer quart segle VII',651,675,1),(77,'últim quart segle VII',676,700,1),(78,'segle VIII',701,800,1),(79,'primera meitat segle VIII',701,750,1),(80,'primer quart segle VIII',701,725,1),(81,'segon quart segle VIII',726,750,1),(82,'segona meitat segle VIII',751,800,1),(83,'tercer quart segle VIII',751,775,1),(84,'últim quart segle VIII',776,800,1),(85,'segle IX',801,900,1),(86,'primera meitat segle IX',801,850,1),(87,'primer quart segle IX',801,825,1),(88,'segon quart segle IX',826,850,1),(89,'segona meitat segle IX',851,900,1),(90,'tercer quart segle IX',851,875,1),(91,'últim quart segle IX',876,900,1),(92,'segle X',901,1000,1),(93,'primera meitat segle X',901,950,1),(94,'primer quart segle X',901,925,1),(95,'segon quart segle X',926,950,1),(96,'segona meitat segle X',951,1000,1),(97,'tercer quart segle X',951,975,1),(98,'últim quart segle X',976,1000,1),(99,'segle XI',1001,1100,1),(100,'primera meitat segle XI',1001,1050,1),(101,'primer quart segle XI',1001,1025,1),(102,'segon quart segle XI',1026,1050,1),(103,'segona meitat segle XI',1051,1100,1),(104,'tercer quart segle XI',1051,1075,1),(105,'últim quart segle XI',1076,1100,1),(106,'segle XII',1101,1200,1),(107,'primera meitat segle XII',1101,1150,1),(108,'primer quart segle XII',1101,1125,1),(109,'segon quart segle XII',1126,1150,1),(110,'segona meitat segle XII',1151,1200,1),(111,'tercer quart segle XII',1151,1175,1),(112,'últim quart segle XII',1176,1200,1),(113,'segle XIII',1201,1300,1),(114,'primera meitat segle XIII',1201,1250,1),(115,'primer quart segle XIII',1201,1225,1),(116,'segon quart segle XIII',1226,1250,1),(117,'segona meitat segle XIII',1251,1300,1),(118,'tercer quart segle XIII',1251,1275,1),(119,'últim quart segle XIII',1276,1300,1),(120,'segle XIV',1301,1400,1),(121,'primera meitat segle XIV',1301,1350,1),(122,'primer quart segle XIV',1301,1325,1),(123,'segon quart segle XIV',1326,1350,1),(242,'segona meitat segle XIV',1351,1400,1),(243,'tercer quart segle XIV',1351,1375,1),(244,'últim quart segle XIV',1376,1400,1),(245,'segle XV',1401,1500,1),(246,'primera meitat segle XV',1401,1550,1),(247,'primer quart segle XV',1401,1425,1),(248,'segon quart segle XV',1426,1450,1),(249,'segona meitat segle XV',1451,1500,1),(250,'tercer quart segle XV',1451,1475,1),(251,'últim quart segle XV',1476,1500,1),(252,'segle XVI',1501,1600,1),(253,'primera meitat segle XVI',1501,1550,1),(254,'primer quart segle XVI',1501,1525,1),(255,'segon quart segle XVI',1526,1550,1),(256,'segona meitat segle XVI',1551,1600,1),(257,'tercer quart segle XVI',1551,1575,1),(258,'últim quart segle XVI',1576,1600,1),(259,'segle XVII',1601,1700,1),(260,'primera meitat segle XVII',1601,1650,1),(261,'primer quart segle XVII',1601,1625,1),(262,'segon quart segle XVII',1626,1650,1),(263,'segona meitat segle XVII',1651,1700,1),(264,'tercer quart segle XVII',1651,1675,1),(265,'últim quart segle XVII',1676,1700,1),(266,'segle XVIII',1701,1800,1),(267,'primera meitat segle XVIII',1701,1750,1),(268,'primer quart segle XVIII',1701,1725,1),(269,'segon quart segle XVIII',1726,1750,1),(270,'segona meitat segle XVIII',1751,1800,1),(271,'tercer quart segle XVIII',1751,1775,1),(272,'últim quart segle XVIII',1776,1800,1),(273,'segle XIX',1801,1900,1),(274,'primera meitat segle XIX',1801,1850,1),(275,'primer quart segle XIX',1801,1825,1),(276,'dècada de 1800',1801,1810,1),(277,'dècada de 1810',1811,1820,1),(278,'dècada de 1820',1821,1830,1),(279,'segon quart segle XIX',1826,1850,1),(280,'dècada de 1830',1831,1840,1),(281,'dècada de 1840',1841,1850,1),(282,'segona meitat segle XIX',1851,1900,1),(283,'tercer quart segle XIX',1851,1875,1),(284,'dècada de 1850',1851,1860,1),(285,'dècada de 1860',1861,1870,1),(286,'dècada de 1870',1871,1880,1),(287,'últim quart segle XIX',1876,1900,1),(288,'dècada de 1880',1881,1890,1),(289,'dècada de 1890',1891,1900,1),(290,'segle XX',1901,2000,1),(291,'primera meitat segle XX',1901,1950,1),(292,'primer quart segle XX',1901,1925,1),(293,'dècada de 1900',1901,1910,1),(294,'dècada de 1910',1911,1920,1),(295,'dècada de 1920 i 1930',1921,1940,1),(296,'dècada de 1920',1921,1930,1),(297,'segon quart segle XX',1926,1950,1),(298,'dècada de 1930 i 1940',1931,1950,1),(299,'dècada de 1930',1931,1940,1),(300,'dècada de 1940',1941,1950,1),(301,'segona meitat segle XX',1951,2000,1),(302,'tercer quart segle XX',1951,1975,1),(303,'dècada de 1950',1951,1960,1),(304,'dècada de 1960',1961,1970,1),(305,'dècada de 1970',1971,1980,1),(306,'últim quart segle XX',1976,2000,1),(307,'dècada de 1980',1981,1990,1),(308,'dècada de 1990',1991,2000,1),(309,'segle XXI',2001,2100,1),(310,'primera meitat segle XXI',2001,2050,1),(311,'primer quart segle XXI',2001,2025,1),(312,'segon quart segle XXI',2026,2050,1),(314,'circa',NULL,NULL,1),(315,'posterior',NULL,NULL,1),(316,'precís',NULL,NULL,1),(317,'paleolític',-3000000,-9000,1),(318,'paleolític inferior',-3000000,-120000,1),(319,'paleolític inferior arcaic',-3000000,-600000,1),(320,'paleolític inferior peces evolucionades',-599999,-120000,1),(321,'paleolític inferior-mig indiferenciat',-119999,-50000,1),(322,'paleolític mig',-89999,-33000,1),(323,'paleolític superior',-22999,-9000,1),(324,'paleolític-epipaleolític',-10999,-7000,1),(325,'epipaleolític',-8999,-5000,1),(326,'neolític',-5499,-2200,1),(327,'neolític antic',-5499,-3500,1),(328,'neolític antic cardial',-5499,-4000,1),(329,'neolític antic postcardial',-3999,-3500,1),(330,'neolític mig-recent',-3499,-2500,1),(331,'neolític final',-2499,-2000,1),(332,'calcolític',-2199,-1800,1),(333,'bronze',-1799,-650,1),(334,'bronze antic',-1799,-1500,1),(335,'bronze mig',-1499,-1200,1),(336,'bronze final',-1199,-650,1),(337,'ferro-ibèric-colonitzacions',-649,50,1),(338,'ferro-ibèric antic',-649,-450,1),(339,'ferro-ibèric ple',-449,-200,1),(340,'romà',-218,476,1),(341,'romà república',-218,-50,1),(342,'ferro-ibèric final',-199,-50,1),(343,'romà August',-27,14,1),(344,'romà alt imperi',14,192,1),(345,'romà segle III',192,284,1),(346,'romà baix imperi',284,476,1),(347,'medieval',400,1492,1),(348,'medieval domini visigòtic',401,715,1),(349,'medieval ocupació i domini musulmà',715,799,1),(350,'medieval món islàmic',800,1150,1),(351,'medieval Catalunya vella sota Carolingis',800,988,1),(352,'medieval món islàmic Emirat',800,899,1),(353,'medieval món islàmic Califat',900,1015,1),(354,'medieval comptes de Barcelona',988,1150,1),(355,'medieval món islàmic Taifes',1016,1150,1),(356,'medieval consolidació Corona d\'Aragó',1150,1230,1),(357,'medieval baixa edat mitjana',1230,1492,1),(358,'modern',1492,1789,1),(359,'contemporani',1798,NULL,1);
/*!40000 ALTER TABLE `datations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `URL` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `artwork` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Documents_Artwork` (`artwork`) USING BTREE,
  CONSTRAINT `FK_Documents_Artwork` FOREIGN KEY (`artwork`) REFERENCES `artworks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entry`
--

DROP TABLE IF EXISTS `entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entry` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entry`
--

LOCK TABLES `entry` WRITE;
/*!40000 ALTER TABLE `entry` DISABLE KEYS */;
INSERT INTO `entry` VALUES (1,'cessio',1),(2,'comodat',1),(3,'compra',1),(4,'dació',1),(5,'desconeguda',1),(6,'dipòsit',1),(7,'donació',1),(8,'entrega obligatòria',1),(9,'excavació',1),(10,'expropiació',1),(11,'herència',1),(12,'intercanvi',1),(13,'llegat',1),(14,'ocupació',1),(15,'ofrena',1),(16,'permuta',1),(17,'premi',1),(18,'propietat directa',1),(19,'recol.lecció',1),(20,'recuperació',1),(22,'successió interadministrativa',1),(37,'olaa',1);
/*!40000 ALTER TABLE `entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expositions`
--

DROP TABLE IF EXISTS `expositions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expositions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `expositionlocation` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `expositiontype` int DEFAULT NULL,
  `start_date` date NOT NULL DEFAULT (curdate()),
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_expositions_expositiontypes` (`expositiontype`),
  CONSTRAINT `FK_expositions_expositiontypes` FOREIGN KEY (`expositiontype`) REFERENCES `expositiontypes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expositions`
--

LOCK TABLES `expositions` WRITE;
/*!40000 ALTER TABLE `expositions` DISABLE KEYS */;
INSERT INTO `expositions` VALUES (33,'Exposició de prova','Museu Apel·les Fenosa',2,'2024-11-13','2024-11-30'),(34,'Prova','Museu Apel·les Fenosa',2,'2024-11-13','2024-11-30'),(35,'Exposicio finalitzada','Museu Apel·les Fenosa',2,'2024-11-10','2024-11-12'),(36,'Exposició de prova 2','Museo Infanta',1,'2024-11-13','2024-11-20'),(37,'exposició de Goda','Museu Apel·les Fenosa',2,'2024-12-03','2025-01-17'),(38,'PROJECT','Museu Apel·les Fenosa',1,'2024-12-04','2024-12-04'),(39,'aaaa','Museu Apel·les Fenosa',2,'2024-12-11','2024-12-21'),(40,'Asas','Asass',2,'2024-12-11','2024-12-12');
/*!40000 ALTER TABLE `expositions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expositionsartworks`
--

DROP TABLE IF EXISTS `expositionsartworks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expositionsartworks` (
  `artwork` int DEFAULT NULL,
  `exposition` int DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `FK__artworks` (`artwork`),
  KEY `FK__expositions` (`exposition`),
  CONSTRAINT `FK__expositions` FOREIGN KEY (`exposition`) REFERENCES `expositions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expositionsartworks`
--

LOCK TABLES `expositionsartworks` WRITE;
/*!40000 ALTER TABLE `expositionsartworks` DISABLE KEYS */;
INSERT INTO `expositionsartworks` VALUES (195,34,140),(203,34,142),(211,33,146),(235,33,148),(216,33,149),(217,33,150),(219,33,151),(205,34,153),(208,34,154),(200,34,156),(207,34,157),(206,34,158),(209,34,159),(210,34,160),(211,34,161),(212,34,162),(199,35,165),(200,35,166),(195,36,167),(196,36,169),(197,36,170),(195,33,171),(196,33,172),(342,33,176),(361,33,177),(357,33,178),(363,33,179),(343,33,180),(362,33,181),(360,33,182),(361,37,192),(363,37,193),(362,37,194),(342,39,197),(343,39,198);
/*!40000 ALTER TABLE `expositionsartworks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expositiontypes`
--

DROP TABLE IF EXISTS `expositiontypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expositiontypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expositiontypes`
--

LOCK TABLES `expositiontypes` WRITE;
/*!40000 ALTER TABLE `expositiontypes` DISABLE KEYS */;
INSERT INTO `expositiontypes` VALUES (1,'Aliena',1),(2,'Propia',1);
/*!40000 ALTER TABLE `expositiontypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genericclassifications`
--

DROP TABLE IF EXISTS `genericclassifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genericclassifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genericclassifications`
--

LOCK TABLES `genericclassifications` WRITE;
/*!40000 ALTER TABLE `genericclassifications` DISABLE KEYS */;
INSERT INTO `genericclassifications` VALUES (1,'Classificació de prova',1);
/*!40000 ALTER TABLE `genericclassifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gettycodes`
--

DROP TABLE IF EXISTS `gettycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gettycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gettycodes`
--

LOCK TABLES `gettycodes` WRITE;
/*!40000 ALTER TABLE `gettycodes` DISABLE KEYS */;
INSERT INTO `gettycodes` VALUES (3,234589);
/*!40000 ALTER TABLE `gettycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `URL` text NOT NULL,
  `artwork` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Images_Artwork` (`artwork`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (9,'uploads/1732008768_3753.jpg',358),(10,'uploads/1733159417_9133.png',364);
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `parent` int DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Location_Location` (`parent`) USING BTREE,
  CONSTRAINT `FK_Location_Location` FOREIGN KEY (`parent`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (10,'Edifici Principal',NULL),(64,'Planta 1',10),(65,'Planta 2',10),(66,'Planta 3',10),(67,'Sala 3',64),(68,'Sala 25',66);
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materialgetty`
--

DROP TABLE IF EXISTS `materialgetty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materialgetty` (
  `id` int NOT NULL AUTO_INCREMENT,
  `gettycode` varchar(50) DEFAULT NULL,
  `text` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materialgetty`
--

LOCK TABLES `materialgetty` WRITE;
/*!40000 ALTER TABLE `materialgetty` DISABLE KEYS */;
INSERT INTO `materialgetty` VALUES (2,'12345','Ejemplo de material Getty',1);
/*!40000 ALTER TABLE `materialgetty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materialgettycodes`
--

DROP TABLE IF EXISTS `materialgettycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materialgettycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materialgettycodes`
--

LOCK TABLES `materialgettycodes` WRITE;
/*!40000 ALTER TABLE `materialgettycodes` DISABLE KEYS */;
INSERT INTO `materialgettycodes` VALUES (1,'08313',1);
/*!40000 ALTER TABLE `materialgettycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materials` (
  `text` varchar(200) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materials`
--

LOCK TABLES `materials` WRITE;
/*!40000 ALTER TABLE `materials` DISABLE KEYS */;
INSERT INTO `materials` VALUES ('Marbre',1,1),('Bronze',5,1),('Pedra',7,1),('Fusta',8,1),('Argila',9,1),('Guix',10,1),('Ferro',11,1),('Ceràmica',12,1),('Resina',13,1),('Fibra de vidre\n\n\n\n\n\n',14,1);
/*!40000 ALTER TABLE `materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movements`
--

DROP TABLE IF EXISTS `movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `place` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `artwork` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Movements_Artwork` (`artwork`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movements`
--

LOCK TABLES `movements` WRITE;
/*!40000 ALTER TABLE `movements` DISABLE KEYS */;
INSERT INTO `movements` VALUES (18,'2024-12-18','2024-12-20','lloco',361),(19,'2024-12-18','2024-12-19','siuimessimessi',362);
/*!40000 ALTER TABLE `movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refs`
--

DROP TABLE IF EXISTS `refs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `URL` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `artwork` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_References_Artwork` (`artwork`) USING BTREE,
  CONSTRAINT `FK_References_Artwork` FOREIGN KEY (`artwork`) REFERENCES `artworks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refs`
--

LOCK TABLES `refs` WRITE;
/*!40000 ALTER TABLE `refs` DISABLE KEYS */;
/*!40000 ALTER TABLE `refs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restorations`
--

DROP TABLE IF EXISTS `restorations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restorations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` tinytext,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `comment` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `authorised_worker_name` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `artwork` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Restoration_Artwork` (`artwork`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restorations`
--

LOCK TABLES `restorations` WRITE;
/*!40000 ALTER TABLE `restorations` DISABLE KEYS */;
INSERT INTO `restorations` VALUES (1,'Cons0001','2024-12-04','2024-12-20','algo','yo mismo',342),(2,'Rest0001','2024-12-10','2015-01-03','si','no ',343),(3,'Rest0002','2024-12-10','2025-04-01','tal vez','puede',357);
/*!40000 ALTER TABLE `restorations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tecniquegettycodes`
--

DROP TABLE IF EXISTS `tecniquegettycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tecniquegettycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tecniquegettycodes`
--

LOCK TABLES `tecniquegettycodes` WRITE;
/*!40000 ALTER TABLE `tecniquegettycodes` DISABLE KEYS */;
INSERT INTO `tecniquegettycodes` VALUES (1,'2409580',1);
/*!40000 ALTER TABLE `tecniquegettycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tecniques`
--

DROP TABLE IF EXISTS `tecniques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tecniques` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tecniques`
--

LOCK TABLES `tecniques` WRITE;
/*!40000 ALTER TABLE `tecniques` DISABLE KEYS */;
INSERT INTO `tecniques` VALUES (1,'Tecnica de prova',1),(6,'Oli sobre tela',1),(7,'Acrílic',1),(8,'Aquarel·la',1),(9,'Tèmpera',1),(10,'Fresc',1),(11,'Pastel',1),(12,'Gouache',1),(13,'Llapis de grafit',1),(14,'Carbó',1),(15,'Tinta',1),(16,'Retolador',1),(17,'Cretes',1),(18,'Llapis de colors',1);
/*!40000 ALTER TABLE `tecniques` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `last_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `email` varchar(180) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` enum('admin','tecnic','convidat') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `profile_img` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'assets/img/defaultprofile.png',
  `creation_date` timestamp NULL DEFAULT (now()),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin','Carla','Pérez Camacho','admin@admin.com','admin','assets/img/adminprofile.png','2024-10-06 15:49:39'),(3,'tecnic','tecnic','Juan-Carlos','Martínez','tecnic@tecnic.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(4,'convidat','convidat','Convidat','','convidat@convidat.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(55,'CarlosG','password123','Carlos','Garcia','carlos.garcia@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(56,'MariaL','password123','Maria','Lopez','maria.lopez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(58,'LuisH','password123','Luis','Hernandez','luis.hernandez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(59,'AnaG','password123','Ana','Gonzalez','ana.gonzalez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(60,'PabloD','password123','Pablo','Diaz','pablo.diaz@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(61,'SaraP','password123','Sara','Perez','sara.perez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(62,'JavierS','password123','Javier','Sanchez','javier.sanchez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(63,'CarmenR','password123','Carmen','Ramirez','carmen.ramirez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(64,'AlbertoF','password123','Alberto','Flores','alberto.flores@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(65,'EvaT','password123','Eva','Torres','eva.torres@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(66,'VictorR','password123','Victor','Rivera','victor.rivera@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(67,'DanielaJ','password123','Daniela','Jimenez','daniela.jimenez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(68,'FranciscoM','password123','Francisco','Morales','francisco.morales@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(69,'ClaraO','password123','Clara','Ortiz','clara.ortiz@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(70,'RaulC','password123','Raul','Castillo','raul.castillo@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(71,'PatriciaG','password123','Patricia','Gil','patricia.gil@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(72,'GabrielR','password123','Gabriel','Ramos','gabriel.ramos@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(73,'TeresaF','password123','Teresa','Fernandez','teresa.fernandez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(74,'AdrianR','password123','Adrian','Ruiz','adrian.ruiz@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(75,'LorenaM','password123','Lorena','Mendoza','lorena.mendoza@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(76,'SergioV','password123','Sergio','Vega','sergio.vega@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(77,'AliciaS','password123','Alicia','Santos','alicia.santos@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(80,'DiegoA','password123','Diego','Acosta','diego.acosta@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(82,'JorgeN','password123','Jorge','Navarro','jorge.navarro@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(83,'ElenaR','password123','Elena','Reyes','elena.reyes@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(84,'AlfredoP','password123','Alfredo','Pena','alfredo.pena@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(85,'CristinaH','password123','Cristina','Herrera','cristina.herrera@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(86,'RamonG','password123','Ramon','Garcia','ramon.garcia@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(87,'MartaG','password123','Marta','Gutierrez','marta.gutierrez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(88,'RicardoC','password123','Ricardo','Cruz','ricardo.cruz@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(89,'SilviaL','password123','Silvia','Lopez','silvia.lopez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(90,'PedroS','password123','Pedro','Sanchez','pedro.sanchez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(91,'BeatrizM','password123','Beatriz','Moreno','beatriz.moreno@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(92,'EmilioM','password123','Emilio','Martinez','emilio.martinez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(93,'SusanaM','password123','Susana','Molina','susana.molina@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(94,'EduardoP','password123','Eduardo','Perez','eduardo.perez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(96,'AntonioO','password123','Antonio','Ortega','antonio.ortega@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(97,'GloriaD','password123','Gloria','Delgado','gloria.delgado@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(98,'LuisMiguelangel','password123','Lui','Mendes','luis.mendes@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(99,'RosaV','password123','Rosa','Vazquez','rosa.vazquez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(100,'OscarC','password123','Oscar','Cano','oscar.cano@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(101,'MonicaR','password123','Monica ','Rios','monica.rios@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-17  9:47:20
