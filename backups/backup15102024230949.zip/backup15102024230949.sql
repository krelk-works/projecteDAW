-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: bbyirnoypbjzxaryzns9-mysql.services.clever-cloud.com    Database: bbyirnoypbjzxaryzns9
-- ------------------------------------------------------
-- Server version	8.0.22-13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artworks`
--

DROP TABLE IF EXISTS `artworks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artworks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_letter` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `id_num1` int NOT NULL,
  `id_num2` int DEFAULT NULL,
  `name` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci,
  `register_date` date NOT NULL DEFAULT (curdate()),
  `creation_date` date DEFAULT NULL,
  `cost` int DEFAULT NULL,
  `amount` int NOT NULL,
  `location` int DEFAULT NULL,
  `author` int DEFAULT NULL,
  `material` int DEFAULT NULL,
  `conservation` int DEFAULT '5',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Artwork_ID_Location` (`location`) USING BTREE,
  KEY `FK_Artwork_ID_Author` (`author`) USING BTREE,
  KEY `Material_ID` (`material`) USING BTREE,
  KEY `Conservation_ID` (`conservation`) USING BTREE,
  CONSTRAINT `FK_3` FOREIGN KEY (`material`) REFERENCES `materials` (`id`),
  CONSTRAINT `FK_Artwork_Estat de conservacio` FOREIGN KEY (`conservation`) REFERENCES `conservationstatus` (`id`),
  CONSTRAINT `FK_Artwork_ID_Author` FOREIGN KEY (`author`) REFERENCES `authors` (`id`),
  CONSTRAINT `FK_Artwork_ID_Location` FOREIGN KEY (`location`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artworks`
--

LOCK TABLES `artworks` WRITE;
/*!40000 ALTER TABLE `artworks` DISABLE KEYS */;
INSERT INTO `artworks` VALUES (97,'A',1,1,'Obra de Arte 1','Descripción de prueba 1','2024-10-01','2021-01-01',1000,1,11,3,1,1),(98,'B',1,2,'Obra de Arte 2','Descripción de prueba 2','2024-10-01','2020-02-01',2000,2,11,3,1,3),(99,'C',1,3,'Obra de Arte Fenosa','Descripción de prueba siuu','2024-10-01','2019-03-01',3000,1,11,4,1,5),(100,'D',1,4,'Obra de Arte 4','Descripción de prueba 4','2024-10-01','2018-04-01',1500,1,11,3,1,2),(101,'E',1,5,'Obra de Arte 5','Descripción de prueba 5','2024-10-01','2017-05-01',500,2,11,3,1,3),(102,'F',1,6,'Obra de Arte 6','Descripción de prueba 6','2024-10-01','2016-06-01',1200,1,11,3,1,5),(103,'G',1,7,'Obra de Arte 7','Descripción de prueba 7','2024-10-01','2015-07-01',800,1,11,3,1,1),(104,'H',1,8,'Obra de Arte 8','Descripción de prueba 8','2024-10-01','2014-08-01',2500,1,11,3,1,1),(105,'I',1,9,'Obra de Arte 9','Descripción de prueba 9','2024-10-01','2013-09-01',1800,2,11,3,1,1),(106,'J',1,10,'Obra de Arte 10','Descripción de prueba 10','2024-10-01','2012-10-01',2200,1,11,3,1,1),(107,'K',1,11,'Obra de Arte 11','Descripción de prueba 11','2024-10-01','2011-11-01',400,1,11,3,1,1),(108,'L',1,12,'Obra de Arte 12','Descripción de prueba 12','2024-10-01','2010-12-01',600,1,11,3,1,2),(109,'M',1,13,'Obra de Arte 13','Descripción de prueba 13','2024-10-01','2009-01-01',3200,1,11,3,1,3),(110,'N',1,14,'Obra de Arte 14','Descripción de prueba 14','2024-10-01','2008-02-01',500,1,11,3,1,4),(111,'O',1,15,'Obra de Arte 15','Descripción de prueba 15','2024-10-01','2007-03-01',1300,1,11,3,1,3),(112,'P',1,16,'Obra de Arte 16','Descripción de prueba 16','2024-10-01','2006-04-01',900,2,11,3,1,4),(113,'Q',1,17,'Obra de Arte 17','Descripción de prueba 17','2024-10-01','2005-05-01',2100,1,11,3,1,3),(114,'R',1,18,'Obra de Arte 18','Descripción de prueba 18','2024-10-01','2004-06-01',300,1,11,3,1,4),(115,'S',1,19,'Obra de Arte 19','Descripción de prueba 19','2024-10-01','2003-07-01',1400,1,11,3,1,3),(116,'T',1,20,'Obra de Arte 20','Descripción de prueba 20','2024-10-01','2002-08-01',2000,1,11,3,NULL,2),(117,'U',1,21,'Obra de Arte 21','Descripción de prueba 21','2024-10-01','2001-09-01',3500,1,11,3,1,5),(118,'V',1,22,'Obra de Arte 22','Descripción de prueba 22','2024-10-01','2000-10-01',1800,1,11,3,1,5),(119,'W',1,23,'Obra de Arte 23','Descripción de prueba 23','2024-10-01','1999-11-01',700,2,11,3,1,3),(120,'X',1,24,'Obra de Arte 24','Descripción de prueba 24','2024-10-01','1998-12-01',2600,1,11,3,1,4),(121,'Y',1,25,'Obra de Arte 25','Descripción de prueba 25','2024-10-01','1997-01-01',1500,1,11,3,1,6),(122,'Z',1,26,'Obra de Arte 26','Descripción de prueba 26','2024-10-01','1996-02-01',800,1,11,3,1,2),(123,'A',1,27,'Obra de Arte 27','Descripción de prueba 27','2024-10-01','1995-03-01',1700,1,11,3,1,4),(124,'B',1,28,'Obra de Arte 28','Descripción de prueba 28','2024-10-01','1994-04-01',1100,1,11,3,1,5),(125,'C',1,29,'Obra de Arte 29','Descripción de prueba 29','2024-10-01','1993-05-01',1300,1,11,3,1,6),(126,'D',1,30,'Obra de Arte 30','Descripción de prueba 30','2024-10-01','1992-06-01',1600,2,11,3,1,5),(127,'E',1,31,'Obra de Arte 31','Descripción de prueba 31','2024-10-01','1991-07-01',2400,1,11,3,1,1),(128,'F',1,32,'Obra de Arte 32','Descripción de prueba 32','2024-10-01','1990-08-01',1200,1,11,3,1,5),(129,'G',1,33,'Obra de Arte 33','Descripción de prueba 33','2024-10-01','1989-09-01',2800,1,11,3,1,3),(130,'H',1,34,'Obra de Arte 34','Descripción de prueba 34','2024-10-01','1988-10-01',500,1,11,3,1,3),(131,'I',1,35,'Obra de Arte 35','Descripción de prueba 35','2024-10-01','1987-11-01',900,1,11,3,1,2),(132,'J',1,36,'Obra de Arte 36','Descripción de prueba 36','2024-10-01','1986-12-01',3200,1,11,3,1,5),(133,'K',1,37,'Obra de Arte 37','Descripción de prueba 37','2024-10-01','1985-01-01',5000,1,11,3,1,4),(134,'L',1,38,'Obra de Arte 38','Descripción de prueba 38','2024-10-01','1984-02-01',1300,1,11,3,1,6),(135,'M',1,39,'Obra de Arte 39','Descripción de prueba 39','2024-10-01','1983-03-01',400,1,11,3,1,2),(136,'N',1,40,'Obra de Arte 40','Descripción de prueba 40','2024-10-01','1982-04-01',2000,1,11,3,1,1);
/*!40000 ALTER TABLE `artworks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '',
  `birthdate` date DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (3,'Apel·les Fenosa',NULL),(4,'Apel·les ',NULL),(5,'Leonardo Da Vinci',NULL);
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cancelcauses`
--

DROP TABLE IF EXISTS `cancelcauses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cancelcauses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancelcauses`
--

LOCK TABLES `cancelcauses` WRITE;
/*!40000 ALTER TABLE `cancelcauses` DISABLE KEYS */;
INSERT INTO `cancelcauses` VALUES (1,'Confiscació'),(2,'Destrucció'),(3,'Estat de conservació molt deficient'),(4,'Manteniment i restauració onerós'),(5,'Pèrdua'),(6,'Robatori'),(7,'Successió interadministrativa'),(8,'Valor patrimonial insuficient');
/*!40000 ALTER TABLE `cancelcauses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cancels`
--

DROP TABLE IF EXISTS `cancels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cancels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cancelcause` int NOT NULL DEFAULT '0',
  `authorised_worker_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `artwork` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Cancels_Artwork` (`artwork`) USING BTREE,
  KEY `FK_cancels_cancelcauses` (`cancelcause`) USING BTREE,
  CONSTRAINT `FK_cancels_artworks` FOREIGN KEY (`artwork`) REFERENCES `artworks` (`id`),
  CONSTRAINT `FK_cancels_cancelcauses` FOREIGN KEY (`cancelcause`) REFERENCES `cancelcauses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancels`
--

LOCK TABLES `cancels` WRITE;
/*!40000 ALTER TABLE `cancels` DISABLE KEYS */;
/*!40000 ALTER TABLE `cancels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conservationstatus`
--

DROP TABLE IF EXISTS `conservationstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conservationstatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conservationstatus`
--

LOCK TABLES `conservationstatus` WRITE;
/*!40000 ALTER TABLE `conservationstatus` DISABLE KEYS */;
INSERT INTO `conservationstatus` VALUES (1,'Bo'),(2,'Dolent'),(3,'Excel·lent'),(4,'Indeterminat'),(5,'desconeguda'),(6,'Regular');
/*!40000 ALTER TABLE `conservationstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datations`
--

DROP TABLE IF EXISTS `datations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL,
  `start_date` int DEFAULT '0',
  `end_date` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=360 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datations`
--

LOCK TABLES `datations` WRITE;
/*!40000 ALTER TABLE `datations` DISABLE KEYS */;
INSERT INTO `datations` VALUES (1,'segle IV ante',-400,-301),(2,'primera meitat segle IV ante',-400,-351),(3,'primer quart segle IV ante',-400,-376),(4,'segon quart segle IV ante',-375,-351),(5,'segona meitat segle IV ante',-350,-301),(6,'tercer quart segle IV ante',-350,-326),(7,'últim quart segle IV ante',-325,-301),(8,'segle III ante',-300,-201),(9,'primera meitat segle III ante',-300,-251),(10,'primer quart segle III ante',-300,-276),(11,'segon quart segle III ante',-275,-251),(12,'segona meitat segle III ante',-250,-201),(13,'tercer quart segle III ante',-250,-226),(14,'últim quart segle III ante',-225,-201),(15,'segle II ante',-200,-101),(16,'primera meitat segle II ante',-200,-151),(17,'primer quart segle II ante',-200,-176),(18,'segon quart segle II ante',-175,-151),(19,'segona meitat segle II ante',-150,-101),(20,'tercer quart segle II ante',-150,-126),(21,'últim quart segle II ante',-125,-101),(22,'segle I ante',-100,-1),(23,'primera meitat segle I ante',-100,-51),(24,'primer quart segle I ante',-100,-76),(25,'segon quart segle I ante',-75,-51),(26,'segona meitat segle I ante',-50,-1),(27,'tercer quart segle I ante',-50,-26),(28,'últim quart segle I ante',-25,-1),(29,'segle I',1,100),(30,'primera meitat segle I',1,50),(31,'primer quart segle I',1,25),(32,'segon quart segle I',26,50),(33,'segona meitat segle I',51,100),(34,'tercer quart segle I',51,75),(35,'últim quart segle I',76,100),(36,'segle II',101,200),(37,'primera meitat segle II',101,150),(38,'primer quart segle II',101,125),(39,'segon quart segle II',126,150),(40,'segona meitat segle II',151,200),(41,'tercer quart segle II',151,175),(42,'últim quart segle II',176,200),(43,'segle III',201,300),(44,'primera meitat segle III',201,250),(45,'primer quart segle III',201,225),(46,'segon quart segle III',226,250),(47,'segona meitat segle III',251,300),(48,'tercer quart segle III',251,275),(49,'últim quart segle III',276,300),(50,'segle IV',301,400),(51,'primera meitat segle IV',301,350),(52,'primer quart segle IV',301,325),(53,'segon quart segle IV',326,350),(54,'segona meitat segle IV',351,400),(55,'tercer quart segle IV',351,375),(56,'últim quart segle IV',376,400),(57,'segle V',401,500),(58,'primera meitat segle V',401,450),(59,'primer quart segle V',401,425),(60,'segon quart segle V',426,450),(61,'segona meitat segle V',451,500),(62,'tercer quart segle V',451,475),(63,'últim quart segle V',476,500),(64,'segle VI',501,600),(65,'primera meitat segle VI',501,550),(66,'primer quart segle VI',501,525),(67,'segon quart segle VI',526,550),(68,'segona meitat segle VI',551,600),(69,'tercer quart segle VI',551,575),(70,'últim quart segle VI',576,600),(71,'segle VII',601,700),(72,'primera meitat segle VII',601,650),(73,'primer quart segle VII',601,625),(74,'segon quart segle VII',626,650),(75,'segona meitat segle VII',651,700),(76,'tercer quart segle VII',651,675),(77,'últim quart segle VII',676,700),(78,'segle VIII',701,800),(79,'primera meitat segle VIII',701,750),(80,'primer quart segle VIII',701,725),(81,'segon quart segle VIII',726,750),(82,'segona meitat segle VIII',751,800),(83,'tercer quart segle VIII',751,775),(84,'últim quart segle VIII',776,800),(85,'segle IX',801,900),(86,'primera meitat segle IX',801,850),(87,'primer quart segle IX',801,825),(88,'segon quart segle IX',826,850),(89,'segona meitat segle IX',851,900),(90,'tercer quart segle IX',851,875),(91,'últim quart segle IX',876,900),(92,'segle X',901,1000),(93,'primera meitat segle X',901,950),(94,'primer quart segle X',901,925),(95,'segon quart segle X',926,950),(96,'segona meitat segle X',951,1000),(97,'tercer quart segle X',951,975),(98,'últim quart segle X',976,1000),(99,'segle XI',1001,1100),(100,'primera meitat segle XI',1001,1050),(101,'primer quart segle XI',1001,1025),(102,'segon quart segle XI',1026,1050),(103,'segona meitat segle XI',1051,1100),(104,'tercer quart segle XI',1051,1075),(105,'últim quart segle XI',1076,1100),(106,'segle XII',1101,1200),(107,'primera meitat segle XII',1101,1150),(108,'primer quart segle XII',1101,1125),(109,'segon quart segle XII',1126,1150),(110,'segona meitat segle XII',1151,1200),(111,'tercer quart segle XII',1151,1175),(112,'últim quart segle XII',1176,1200),(113,'segle XIII',1201,1300),(114,'primera meitat segle XIII',1201,1250),(115,'primer quart segle XIII',1201,1225),(116,'segon quart segle XIII',1226,1250),(117,'segona meitat segle XIII',1251,1300),(118,'tercer quart segle XIII',1251,1275),(119,'últim quart segle XIII',1276,1300),(120,'segle XIV',1301,1400),(121,'primera meitat segle XIV',1301,1350),(122,'primer quart segle XIV',1301,1325),(123,'segon quart segle XIV',1326,1350),(242,'segona meitat segle XIV',1351,1400),(243,'tercer quart segle XIV',1351,1375),(244,'últim quart segle XIV',1376,1400),(245,'segle XV',1401,1500),(246,'primera meitat segle XV',1401,1550),(247,'primer quart segle XV',1401,1425),(248,'segon quart segle XV',1426,1450),(249,'segona meitat segle XV',1451,1500),(250,'tercer quart segle XV',1451,1475),(251,'últim quart segle XV',1476,1500),(252,'segle XVI',1501,1600),(253,'primera meitat segle XVI',1501,1550),(254,'primer quart segle XVI',1501,1525),(255,'segon quart segle XVI',1526,1550),(256,'segona meitat segle XVI',1551,1600),(257,'tercer quart segle XVI',1551,1575),(258,'últim quart segle XVI',1576,1600),(259,'segle XVII',1601,1700),(260,'primera meitat segle XVII',1601,1650),(261,'primer quart segle XVII',1601,1625),(262,'segon quart segle XVII',1626,1650),(263,'segona meitat segle XVII',1651,1700),(264,'tercer quart segle XVII',1651,1675),(265,'últim quart segle XVII',1676,1700),(266,'segle XVIII',1701,1800),(267,'primera meitat segle XVIII',1701,1750),(268,'primer quart segle XVIII',1701,1725),(269,'segon quart segle XVIII',1726,1750),(270,'segona meitat segle XVIII',1751,1800),(271,'tercer quart segle XVIII',1751,1775),(272,'últim quart segle XVIII',1776,1800),(273,'segle XIX',1801,1900),(274,'primera meitat segle XIX',1801,1850),(275,'primer quart segle XIX',1801,1825),(276,'dècada de 1800',1801,1810),(277,'dècada de 1810',1811,1820),(278,'dècada de 1820',1821,1830),(279,'segon quart segle XIX',1826,1850),(280,'dècada de 1830',1831,1840),(281,'dècada de 1840',1841,1850),(282,'segona meitat segle XIX',1851,1900),(283,'tercer quart segle XIX',1851,1875),(284,'dècada de 1850',1851,1860),(285,'dècada de 1860',1861,1870),(286,'dècada de 1870',1871,1880),(287,'últim quart segle XIX',1876,1900),(288,'dècada de 1880',1881,1890),(289,'dècada de 1890',1891,1900),(290,'segle XX',1901,2000),(291,'primera meitat segle XX',1901,1950),(292,'primer quart segle XX',1901,1925),(293,'dècada de 1900',1901,1910),(294,'dècada de 1910',1911,1920),(295,'dècada de 1920 i 1930',1921,1940),(296,'dècada de 1920',1921,1930),(297,'segon quart segle XX',1926,1950),(298,'dècada de 1930 i 1940',1931,1950),(299,'dècada de 1930',1931,1940),(300,'dècada de 1940',1941,1950),(301,'segona meitat segle XX',1951,2000),(302,'tercer quart segle XX',1951,1975),(303,'dècada de 1950',1951,1960),(304,'dècada de 1960',1961,1970),(305,'dècada de 1970',1971,1980),(306,'últim quart segle XX',1976,2000),(307,'dècada de 1980',1981,1990),(308,'dècada de 1990',1991,2000),(309,'segle XXI',2001,2100),(310,'primera meitat segle XXI',2001,2050),(311,'primer quart segle XXI',2001,2025),(312,'segon quart segle XXI',2026,2050),(313,'abans',NULL,NULL),(314,'circa',NULL,NULL),(315,'posterior',NULL,NULL),(316,'precís',NULL,NULL),(317,'paleolític',-3000000,-9000),(318,'paleolític inferior',-3000000,-120000),(319,'paleolític inferior arcaic',-3000000,-600000),(320,'paleolític inferior peces evolucionades',-599999,-120000),(321,'paleolític inferior-mig indiferenciat',-119999,-50000),(322,'paleolític mig',-89999,-33000),(323,'paleolític superior',-22999,-9000),(324,'paleolític-epipaleolític',-10999,-7000),(325,'epipaleolític',-8999,-5000),(326,'neolític',-5499,-2200),(327,'neolític antic',-5499,-3500),(328,'neolític antic cardial',-5499,-4000),(329,'neolític antic postcardial',-3999,-3500),(330,'neolític mig-recent',-3499,-2500),(331,'neolític final',-2499,-2000),(332,'calcolític',-2199,-1800),(333,'bronze',-1799,-650),(334,'bronze antic',-1799,-1500),(335,'bronze mig',-1499,-1200),(336,'bronze final',-1199,-650),(337,'ferro-ibèric-colonitzacions',-649,50),(338,'ferro-ibèric antic',-649,-450),(339,'ferro-ibèric ple',-449,-200),(340,'romà',-218,476),(341,'romà república',-218,-50),(342,'ferro-ibèric final',-199,-50),(343,'romà August',-27,14),(344,'romà alt imperi',14,192),(345,'romà segle III',192,284),(346,'romà baix imperi',284,476),(347,'medieval',400,1492),(348,'medieval domini visigòtic',401,715),(349,'medieval ocupació i domini musulmà',715,799),(350,'medieval món islàmic',800,1150),(351,'medieval Catalunya vella sota Carolingis',800,988),(352,'medieval món islàmic Emirat',800,899),(353,'medieval món islàmic Califat',900,1015),(354,'medieval comptes de Barcelona',988,1150),(355,'medieval món islàmic Taifes',1016,1150),(356,'medieval consolidació Corona d\'Aragó',1150,1230),(357,'medieval baixa edat mitjana',1230,1492),(358,'modern',1492,1789),(359,'contemporani',1798,NULL);
/*!40000 ALTER TABLE `datations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entry`
--

DROP TABLE IF EXISTS `entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entry` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entry`
--

LOCK TABLES `entry` WRITE;
/*!40000 ALTER TABLE `entry` DISABLE KEYS */;
INSERT INTO `entry` VALUES (1,'cessio'),(2,'comodat'),(3,'compra'),(4,'dació'),(5,'desconeguda'),(6,'dipòsit'),(7,'donació'),(8,'entrega obligatòria'),(9,'excavació'),(10,'expropiació'),(11,'herència'),(12,'intercanvi'),(13,'llegat'),(14,'ocupació'),(15,'ofrena'),(16,'permuta'),(17,'premi'),(18,'propietat directa'),(19,'recol.lecció'),(20,'recuperació'),(21,'successió interadministrativa');
/*!40000 ALTER TABLE `entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expositiontypes`
--

DROP TABLE IF EXISTS `expositiontypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expositiontypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expositiontypes`
--

LOCK TABLES `expositiontypes` WRITE;
/*!40000 ALTER TABLE `expositiontypes` DISABLE KEYS */;
INSERT INTO `expositiontypes` VALUES (1,'Aliena'),(2,'Propia');
/*!40000 ALTER TABLE `expositiontypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genericclassifications`
--

DROP TABLE IF EXISTS `genericclassifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genericclassifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genericclassifications`
--

LOCK TABLES `genericclassifications` WRITE;
/*!40000 ALTER TABLE `genericclassifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `genericclassifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `URL` text NOT NULL,
  `artwork` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Images_Artwork` (`artwork`) USING BTREE,
  CONSTRAINT `FK_Images_Artwork` FOREIGN KEY (`artwork`) REFERENCES `artworks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (1,'assets/img/example3.jpg',98),(2,'assets/img/example5.jpg',99),(3,'assets/img/example3.jpg',100),(4,'assets/img/example3.jpg',101),(5,'assets/img/example3.jpg',102),(6,'assets/img/example3.jpg',103),(7,'assets/img/example3.jpg',104),(8,'assets/img/example3.jpg',105),(9,'assets/img/example3.jpg',106),(10,'assets/img/example3.jpg',107),(11,'assets/img/example3.jpg',108),(12,'assets/img/example5.jpg',109),(13,'assets/img/example3.jpg',110),(14,'assets/img/example3.jpg',111),(15,'assets/img/example3.jpg',112),(16,'assets/img/example3.jpg',113),(17,'assets/img/example3.jpg',114),(18,'assets/img/example3.jpg',115),(19,'assets/img/example3.jpg',116),(20,'assets/img/example3.jpg',117),(21,'assets/img/example3.jpg',118),(22,'assets/img/example3.jpg',119),(23,'assets/img/example3.jpg',120),(24,'assets/img/example3.jpg',121),(25,'assets/img/example3.jpg',122),(26,'assets/img/example3.jpg',123),(27,'assets/img/example1.jpg',124),(28,'assets/img/example3.jpg',125),(29,'assets/img/example3.jpg',126),(30,'assets/img/example3.jpg',127),(31,'assets/img/example3.jpg',128),(32,'assets/img/example3.jpg',129),(33,'assets/img/example5.jpg',130),(34,'assets/img/example3.jpg',131),(35,'assets/img/example3.jpg',132),(36,'assets/img/example3.jpg',133),(37,'assets/img/example3.jpg',134),(38,'assets/img/example3.jpg',135),(39,'assets/img/example3.jpg',136);
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `parent` int DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Location_Location` (`parent`) USING BTREE,
  CONSTRAINT `FK_Location_Location` FOREIGN KEY (`parent`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (10,'Edifici principal',NULL),(11,'Planta 1',10),(12,'Planta 2',10),(13,'Planta 3',10),(16,'Sala 1',11),(17,'Sala 2',11),(18,'Sala 3',12),(19,'Sala 4',12),(20,'Sala 5',12),(21,'Sala 6',13),(22,'Sala 7',13),(23,'Sala 8',13);
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materialgettycodes`
--

DROP TABLE IF EXISTS `materialgettycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materialgettycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materialgettycodes`
--

LOCK TABLES `materialgettycodes` WRITE;
/*!40000 ALTER TABLE `materialgettycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `materialgettycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materials` (
  `text` varchar(200) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materials`
--

LOCK TABLES `materials` WRITE;
/*!40000 ALTER TABLE `materials` DISABLE KEYS */;
INSERT INTO `materials` VALUES ('material de ejemplo',1);
/*!40000 ALTER TABLE `materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movements`
--

DROP TABLE IF EXISTS `movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `reason` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `artwork` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Movements_Artwork` (`artwork`) USING BTREE,
  CONSTRAINT `FK_Movements_Artwork` FOREIGN KEY (`artwork`) REFERENCES `artworks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movements`
--

LOCK TABLES `movements` WRITE;
/*!40000 ALTER TABLE `movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restorations`
--

DROP TABLE IF EXISTS `restorations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restorations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `reason` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `artwork` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Restoration_Artwork` (`artwork`) USING BTREE,
  CONSTRAINT `FK_Restoration_Artwork` FOREIGN KEY (`artwork`) REFERENCES `artworks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restorations`
--

LOCK TABLES `restorations` WRITE;
/*!40000 ALTER TABLE `restorations` DISABLE KEYS */;
/*!40000 ALTER TABLE `restorations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tecniquegettycodes`
--

DROP TABLE IF EXISTS `tecniquegettycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tecniquegettycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tecniquegettycodes`
--

LOCK TABLES `tecniquegettycodes` WRITE;
/*!40000 ALTER TABLE `tecniquegettycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tecniquegettycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tecniques`
--

DROP TABLE IF EXISTS `tecniques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tecniques` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tecniques`
--

LOCK TABLES `tecniques` WRITE;
/*!40000 ALTER TABLE `tecniques` DISABLE KEYS */;
/*!40000 ALTER TABLE `tecniques` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `last_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `email` varchar(180) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` enum('admin','tecnic','convidat') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `profile_img` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'assets/img/defaultprofile.png',
  `creation_date` timestamp NULL DEFAULT (now()),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin','Carla','Pérez Camacho','admin@admin.com','admin','assets/img/adminprofile.png','2024-10-06 15:49:39'),(3,'tecnic','tecnic','Juan-Carlos','Martínez','tecnic@tecnic.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(4,'convidat','convidat','Convidat','','convidat@convidat.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(55,'CarlosG','password123','Carlos','Garcia','carlos.garcia@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(56,'MariaL','password123','Maria','Lopez','maria.lopez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(57,'JuanM','password123','Juan','Martinez','juan.martinez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(58,'LuisH','password123','Luis','Hernandez','luis.hernandez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(59,'AnaG','password123','Ana','Gonzalez','ana.gonzalez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(60,'PabloD','password123','Pablo','Diaz','pablo.diaz@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(61,'SaraP','password123','Sara','Perez','sara.perez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(62,'JavierS','password123','Javier','Sanchez','javier.sanchez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(63,'CarmenR','password123','Carmen','Ramirez','carmen.ramirez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(64,'AlbertoF','password123','Alberto','Flores','alberto.flores@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(65,'EvaT','password123','Eva','Torres','eva.torres@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(66,'VictorR','password123','Victor','Rivera','victor.rivera@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(67,'DanielaJ','password123','Daniela','Jimenez','daniela.jimenez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(68,'FranciscoM','password123','Francisco','Morales','francisco.morales@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(69,'ClaraO','password123','Clara','Ortiz','clara.ortiz@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(70,'RaulC','password123','Raul','Castillo','raul.castillo@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(71,'PatriciaG','password123','Patricia','Gil','patricia.gil@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(72,'GabrielR','password123','Gabriel','Ramos','gabriel.ramos@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(73,'TeresaF','password123','Teresa','Fernandez','teresa.fernandez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(74,'AdrianR','password123','Adrian','Ruiz','adrian.ruiz@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(75,'LorenaM','password123','Lorena','Mendoza','lorena.mendoza@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(76,'SergioV','password123','Sergio','Vega','sergio.vega@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(77,'AliciaS','password123','Alicia','Santos','alicia.santos@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(79,'IsabelR','password123','Isabel','Romero','isabel.romero@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(80,'DiegoA','password123','Diego','Acosta','diego.acosta@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(81,'JuliaF','password123','Julia','Ferrer','julia.ferrer@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(82,'JorgeN','password123','Jorge','Navarro','jorge.navarro@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(83,'ElenaR','password123','Elena','Reyes','elena.reyes@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(84,'AlfredoP','password123','Alfredo','Pena','alfredo.pena@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(85,'CristinaH','password123','Cristina','Herrera','cristina.herrera@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(86,'RamonG','password123','Ramon','Garcia','ramon.garcia@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(87,'MartaG','password123','Marta','Gutierrez','marta.gutierrez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(88,'RicardoC','password123','Ricardo','Cruz','ricardo.cruz@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(89,'SilviaL','password123','Silvia','Lopez','silvia.lopez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(90,'PedroS','password123','Pedro','Sanchez','pedro.sanchez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(91,'BeatrizM','password123','Beatriz','Moreno','beatriz.moreno@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(92,'EmilioM','password123','Emilio','Martinez','emilio.martinez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(93,'SusanaM','password123','Susana','Molina','susana.molina@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(94,'EduardoP','password123','Eduardo','Perez','eduardo.perez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(96,'AntonioO','password123','Antonio','Ortega','antonio.ortega@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(97,'GloriaD','password123','Gloria','Delgado','gloria.delgado@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(98,'LuisM','password123','Luis','Mendez','luis.mendez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(99,'RosaV','password123','Rosa','Vazquez','rosa.vazquez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(100,'OscarC','password123','Oscar','Cano','oscar.cano@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(101,'MonicaR','password123','Monica ','Rios','monica.rios@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(177,'asgafa','sagsgsa','sdgsgs','gsg','gsdg@gmail.com','admin','assets/img/Captura de pantalla de 2024-10-15 09-05-18.png','2024-10-15 08:22:03'),(178,'asasa','fasfags','gsdgsdgsgs','dagsagsdg','sdhsd@gmail.com','admin','assets/img/defaultprofile.png','2024-10-15 08:24:19'),(179,'adfa','fafgafa','asfasfsa','fasfasfas','fasfas@gmail.com','admin','assets/img/defaultprofile.png','2024-10-15 08:25:01');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-16  1:09:59
