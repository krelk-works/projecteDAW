-- MySQL dump 10.19  Distrib 10.3.39-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: bbyirnoypbjzxaryzns9-mysql.services.clever-cloud.com    Database: bbyirnoypbjzxaryzns9
-- ------------------------------------------------------
-- Server version	8.0.22-13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artworks`
--

DROP TABLE IF EXISTS `artworks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artworks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `museumname` text,
  `id_letter` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `id_num1` int NOT NULL,
  `id_num2` int NOT NULL,
  `name` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci,
  `provenancecollection` text,
  `register_date` date NOT NULL DEFAULT (curdate()),
  `creation_date` date DEFAULT NULL,
  `height` int DEFAULT NULL,
  `width` int DEFAULT NULL,
  `depth` int DEFAULT NULL,
  `title` text,
  `originplace` text,
  `executionplace` text,
  `triage` text,
  `otheridnumbers` text,
  `cost` int DEFAULT NULL,
  `amount` int NOT NULL,
  `history` longtext CHARACTER SET utf8 COLLATE utf8_general_ci,
  `location` int DEFAULT NULL,
  `author` int DEFAULT NULL,
  `material` int DEFAULT NULL,
  `cancelcause` int DEFAULT NULL,
  `conservationstatus` int DEFAULT NULL,
  `datation` int DEFAULT NULL,
  `entry` int DEFAULT NULL,
  `expositiontype` int DEFAULT NULL,
  `genericclassification` int DEFAULT NULL,
  `materialgettycode` int DEFAULT NULL,
  `movement` int DEFAULT NULL,
  `restoration` int DEFAULT NULL,
  `tecnique` int DEFAULT NULL,
  `tecniquegettycode` int DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Artwork_ID_Location` (`location`) USING BTREE,
  KEY `FK_Artwork_ID_Author` (`author`) USING BTREE,
  KEY `Material_ID` (`material`) USING BTREE,
  KEY `FK_artworks_conservationstatus` (`conservationstatus`),
  KEY `FK_artworks_cancelcauses` (`cancelcause`) USING BTREE,
  KEY `FK_artworks_datations` (`datation`),
  KEY `entry` (`entry`),
  KEY `FK_artworks_expositiontypes` (`expositiontype`),
  KEY `FK_artworks_materialgettycodes` (`materialgettycode`),
  KEY `FK_artworks_restorations` (`restoration`),
  KEY `FK_artworks_movements` (`movement`) USING BTREE,
  KEY `FK_artworks_tecniques` (`tecnique`),
  KEY `FK_artworks_tecniquegettycodes` (`tecniquegettycode`),
  KEY `FK_artworks_genericclassifications` (`genericclassification`) USING BTREE,
  CONSTRAINT `entry` FOREIGN KEY (`entry`) REFERENCES `entry` (`id`),
  CONSTRAINT `FK_3` FOREIGN KEY (`material`) REFERENCES `materials` (`id`),
  CONSTRAINT `FK_Artwork_ID_Author` FOREIGN KEY (`author`) REFERENCES `authors` (`id`),
  CONSTRAINT `FK_Artwork_ID_Location` FOREIGN KEY (`location`) REFERENCES `locations` (`id`),
  CONSTRAINT `FK_artworks_cancelcauses` FOREIGN KEY (`cancelcause`) REFERENCES `cancelcauses` (`id`),
  CONSTRAINT `FK_artworks_conservationstatus` FOREIGN KEY (`conservationstatus`) REFERENCES `conservationstatus` (`id`),
  CONSTRAINT `FK_artworks_datations` FOREIGN KEY (`datation`) REFERENCES `datations` (`id`),
  CONSTRAINT `FK_artworks_expositiontypes` FOREIGN KEY (`expositiontype`) REFERENCES `expositiontypes` (`id`),
  CONSTRAINT `FK_artworks_genericclassifications` FOREIGN KEY (`genericclassification`) REFERENCES `genericclassifications` (`id`),
  CONSTRAINT `FK_artworks_materialgettycodes` FOREIGN KEY (`materialgettycode`) REFERENCES `materialgettycodes` (`id`),
  CONSTRAINT `FK_artworks_movements` FOREIGN KEY (`movement`) REFERENCES `movements` (`id`),
  CONSTRAINT `FK_artworks_restorations` FOREIGN KEY (`restoration`) REFERENCES `restorations` (`id`),
  CONSTRAINT `FK_artworks_tecniquegettycodes` FOREIGN KEY (`tecniquegettycode`) REFERENCES `tecniquegettycodes` (`id`),
  CONSTRAINT `FK_artworks_tecniques` FOREIGN KEY (`tecnique`) REFERENCES `tecniques` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artworks`
--

LOCK TABLES `artworks` WRITE;
/*!40000 ALTER TABLE `artworks` DISABLE KEYS */;
INSERT INTO `artworks` VALUES (97,NULL,'A',1,1,'Obra de Arte 1','Descripción de prueba 1',NULL,'2024-10-01','2021-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1000,1,NULL,11,3,1,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(98,NULL,'B',1,2,'Obra de Arte 2','Descripción de prueba 2',NULL,'2024-10-01','2020-02-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2000,2,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(99,NULL,'C',1,3,'Obra de Arte Fenosa','Descripción de prueba siuu',NULL,'2024-10-01','2019-03-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3000,1,NULL,11,4,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(100,NULL,'D',1,4,'Obra de Arte 4','Descripción de prueba 4',NULL,'2024-10-01','2018-04-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1500,1,NULL,11,3,1,NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(101,NULL,'E',1,5,'Obra de Arte 5','Descripción de prueba 5',NULL,'2024-10-01','2017-05-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500,2,NULL,11,3,1,NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(102,NULL,'F',1,6,'Obra de Arte 6','Descripción de prueba 6',NULL,'2024-10-01','2016-06-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1200,1,NULL,11,3,1,NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(103,NULL,'G',1,7,'Obra de Arte 7','Descripción de prueba 7',NULL,'2024-10-01','2015-07-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,800,1,NULL,11,3,1,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(104,NULL,'H',1,8,'Obra de Arte 8','Descripción de prueba 8',NULL,'2024-10-01','2014-08-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2500,1,NULL,11,3,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(105,NULL,'I',1,9,'Obra de Arte 9','Descripción de prueba 9',NULL,'2024-10-01','2013-09-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1800,2,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(106,NULL,'J',1,10,'Obra de Arte 10','Descripción de prueba 10',NULL,'2024-10-01','2012-10-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2200,1,NULL,11,3,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(107,NULL,'K',1,11,'Obra de Arte 11','Descripción de prueba 11',NULL,'2024-10-01','2011-11-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,400,1,NULL,11,3,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(108,NULL,'L',1,12,'Obra de Arte 12','Descripción de prueba 12',NULL,'2024-10-01','2010-12-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,600,1,NULL,11,3,1,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(109,NULL,'M',1,13,'Obra de Arte 13','Descripción de prueba 13',NULL,'2024-10-01','2009-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3200,1,NULL,11,3,1,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(110,NULL,'N',1,14,'Obra de Arte 14','Descripción de prueba 14',NULL,'2024-10-01','2008-02-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(111,NULL,'O',1,15,'Obra de Arte 15','Descripción de prueba 15',NULL,'2024-10-01','2007-03-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1300,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(112,NULL,'P',1,16,'Obra de Arte 16','Descripción de prueba 16',NULL,'2024-10-01','2006-04-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,900,2,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(113,NULL,'Q',1,17,'Obra de Arte 17','Descripción de prueba 17',NULL,'2024-10-01','2005-05-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2100,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(114,NULL,'R',1,18,'Obra de Arte 18','Descripción de prueba 18',NULL,'2024-10-01','2004-06-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,300,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(115,NULL,'S',1,19,'Obra de Arte 19','Descripción de prueba 19',NULL,'2024-10-01','2003-07-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1400,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(116,NULL,'T',1,20,'Obra de Arte 20','Descripción de prueba 20',NULL,'2024-10-01','2002-08-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2000,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(117,NULL,'U',1,21,'Obra de Arte 21','Descripción de prueba 21',NULL,'2024-10-01','2001-09-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3500,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(118,NULL,'V',1,22,'Obra de Arte 22','Descripción de prueba 22',NULL,'2024-10-01','2000-10-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1800,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(119,NULL,'W',1,23,'Obra de Arte 23','Descripción de prueba 23',NULL,'2024-10-01','1999-11-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,700,2,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(120,NULL,'X',1,24,'Obra de Arte 24','Descripción de prueba 24',NULL,'2024-10-01','1998-12-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2600,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(121,NULL,'Y',1,25,'Obra de Arte 25','Descripción de prueba 25',NULL,'2024-10-01','1997-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1500,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(122,NULL,'Z',1,26,'Obra de Arte 26','Descripción de prueba 26',NULL,'2024-10-01','1996-02-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,800,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(123,NULL,'A',1,27,'Obra de Arte 27','Descripción de prueba 27',NULL,'2024-10-01','1995-03-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1700,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(124,NULL,'B',1,28,'Obra de Arte 28','Descripción de prueba 28',NULL,'2024-10-01','1994-04-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1100,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(125,NULL,'C',1,29,'Obra de Arte 29','Descripción de prueba 29',NULL,'2024-10-01','1993-05-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1300,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(126,NULL,'D',1,30,'Obra de Arte 30','Descripción de prueba 30',NULL,'2024-10-01','1992-06-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1600,2,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(127,NULL,'E',1,31,'Obra de Arte 31','Descripción de prueba 31',NULL,'2024-10-01','1991-07-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2400,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(128,NULL,'F',1,32,'Obra de Arte 32','Descripción de prueba 32',NULL,'2024-10-01','1990-08-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1200,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(129,NULL,'G',1,33,'Obra de Arte 33','Descripción de prueba 33',NULL,'2024-10-01','1989-09-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2800,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(130,NULL,'H',1,34,'Obra de Arte 34','Descripción de prueba 34',NULL,'2024-10-01','1988-10-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,500,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(131,NULL,'I',1,35,'Obra de Arte 35','Descripción de prueba 35',NULL,'2024-10-01','1987-11-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,900,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(132,NULL,'J',1,36,'Obra de Arte 36','Descripción de prueba 36',NULL,'2024-10-01','1986-12-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3200,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(133,NULL,'K',1,37,'Obra de Arte 37','Descripción de prueba 37',NULL,'2024-10-01','1985-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5000,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(134,NULL,'L',1,38,'Obra de Arte 38','Descripción de prueba 38',NULL,'2024-10-01','1984-02-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1300,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(135,NULL,'M',1,39,'Obra de Arte 39','Descripción de prueba 39',NULL,'2024-10-01','1983-03-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,400,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(136,NULL,'N',1,40,'Obra de Arte 40','Descripción de prueba 40',NULL,'2024-10-01','1982-04-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2000,1,NULL,11,3,1,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(144,'ASASAS','',0,0,'ASAS','ASS','','2022-10-10','2022-10-10',0,0,0,'asSASA','','','','',200,3,'VIVA SIUUUU',12,3,1,4,2,15,14,1,1,1,NULL,NULL,NULL,NULL),(145,'ASASAS','A',1,3,'Obra de susmus','aa','asasa','2022-10-10','2022-10-10',5,5,5,'VIVAAAA','mi casa','mis manos','no se ni lo que es','1134',200,5,'VIVA SIUUUU',12,4,1,1,1,15,13,1,1,1,NULL,NULL,NULL,NULL),(146,'','A',1,0,'ASA','','','2022-10-10','2022-10-10',0,0,0,'','','','','',200,1,'',10,3,NULL,NULL,3,2,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(147,'','A',2,0,'ASIUUUU','','','2022-10-10','2022-10-10',0,0,0,'','','','','',100,1,'',10,3,NULL,NULL,2,1,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `artworks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '',
  `birthdate` date DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (3,'Apel·les Fenosa',NULL,1),(4,'Apel·les ',NULL,1),(7,'Viva el betis',NULL,1);
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cancelcauses`
--

DROP TABLE IF EXISTS `cancelcauses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cancelcauses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancelcauses`
--

LOCK TABLES `cancelcauses` WRITE;
/*!40000 ALTER TABLE `cancelcauses` DISABLE KEYS */;
INSERT INTO `cancelcauses` VALUES (1,'Confiscació',1),(2,'Destrucció',1),(3,'Estat de conservació molt deficient',1),(4,'Manteniment i restauració onerós',1),(5,'Pèrdua',1),(6,'Robatori',1),(7,'Successió interadministrativa',1),(8,'Valor patrimonial insuficient',1),(12,'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',0);
/*!40000 ALTER TABLE `cancelcauses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cancels`
--

DROP TABLE IF EXISTS `cancels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cancels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cancelcause` int NOT NULL DEFAULT '0',
  `authorised_worker_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `artwork` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Cancels_Artwork` (`artwork`) USING BTREE,
  KEY `FK_cancels_cancelcauses` (`cancelcause`) USING BTREE,
  CONSTRAINT `FK_cancels_artworks` FOREIGN KEY (`artwork`) REFERENCES `artworks` (`id`),
  CONSTRAINT `FK_cancels_cancelcauses` FOREIGN KEY (`cancelcause`) REFERENCES `cancelcauses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancels`
--

LOCK TABLES `cancels` WRITE;
/*!40000 ALTER TABLE `cancels` DISABLE KEYS */;
/*!40000 ALTER TABLE `cancels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conservationstatus`
--

DROP TABLE IF EXISTS `conservationstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conservationstatus` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conservationstatus`
--

LOCK TABLES `conservationstatus` WRITE;
/*!40000 ALTER TABLE `conservationstatus` DISABLE KEYS */;
INSERT INTO `conservationstatus` VALUES (1,'Bo',1),(2,'Dolent',1),(3,'Excel·lent',1),(4,'Indeterminat',1),(5,'desconeguda',1),(6,'Regular',1);
/*!40000 ALTER TABLE `conservationstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datations`
--

DROP TABLE IF EXISTS `datations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL,
  `start_date` int DEFAULT '0',
  `end_date` int DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=360 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datations`
--

LOCK TABLES `datations` WRITE;
/*!40000 ALTER TABLE `datations` DISABLE KEYS */;
INSERT INTO `datations` VALUES (1,'segle IV ante',-400,-301,1),(2,'primera meitat segle IV ante',-400,-351,1),(3,'primer quart segle IV ante',-400,-376,1),(4,'segon quart segle IV ante',-375,-351,1),(5,'segona meitat segle IV ante',-350,-301,1),(6,'tercer quart segle IV ante',-350,-326,1),(7,'últim quart segle IV ante',-325,-301,1),(8,'segle III ante',-300,-201,1),(9,'primera meitat segle III ante',-300,-251,1),(10,'primer quart segle III ante',-300,-276,1),(11,'segon quart segle III ante',-275,-251,1),(12,'segona meitat segle III ante',-250,-201,1),(13,'tercer quart segle III ante',-250,-226,1),(14,'últim quart segle III ante',-225,-201,1),(15,'segle II ante',-200,-101,1),(16,'primera meitat segle II ante',-200,-151,1),(17,'primer quart segle II ante',-200,-176,1),(18,'segon quart segle II ante',-175,-151,1),(19,'segona meitat segle II ante',-150,-101,1),(20,'tercer quart segle II ante',-150,-126,1),(21,'últim quart segle II ante',-125,-101,1),(22,'segle I ante',-100,-1,1),(23,'primera meitat segle I ante',-100,-51,1),(24,'primer quart segle I ante',-100,-76,1),(25,'segon quart segle I ante',-75,-51,1),(26,'segona meitat segle I ante',-50,-1,1),(27,'tercer quart segle I ante',-50,-26,1),(28,'últim quart segle I ante',-25,-1,1),(29,'segle I',1,100,1),(30,'primera meitat segle I',1,50,1),(31,'primer quart segle I',1,25,1),(32,'segon quart segle I',26,50,1),(33,'segona meitat segle I',51,100,1),(34,'tercer quart segle I',51,75,1),(35,'últim quart segle I',76,100,1),(36,'segle II',101,200,1),(37,'primera meitat segle II',101,150,1),(38,'primer quart segle II',101,125,1),(39,'segon quart segle II',126,150,1),(40,'segona meitat segle II',151,200,1),(41,'tercer quart segle II',151,175,1),(42,'últim quart segle II',176,200,1),(43,'segle III',201,300,1),(44,'primera meitat segle III',201,250,1),(45,'primer quart segle III',201,225,1),(46,'segon quart segle III',226,250,1),(47,'segona meitat segle III',251,300,1),(48,'tercer quart segle III',251,275,1),(49,'últim quart segle III',276,300,1),(50,'segle IV',301,400,1),(51,'primera meitat segle IV',301,350,1),(52,'primer quart segle IV',301,325,1),(53,'segon quart segle IV',326,350,1),(54,'segona meitat segle IV',351,400,1),(55,'tercer quart segle IV',351,375,1),(56,'últim quart segle IV',376,400,1),(57,'segle V',401,500,1),(58,'primera meitat segle V',401,450,1),(59,'primer quart segle V',401,425,1),(60,'segon quart segle V',426,450,1),(61,'segona meitat segle V',451,500,1),(62,'tercer quart segle V',451,475,1),(63,'últim quart segle V',476,500,1),(64,'segle VI',501,600,1),(65,'primera meitat segle VI',501,550,1),(66,'primer quart segle VI',501,525,1),(67,'segon quart segle VI',526,550,1),(68,'segona meitat segle VI',551,600,1),(69,'tercer quart segle VI',551,575,1),(70,'últim quart segle VI',576,600,1),(71,'segle VII',601,700,1),(72,'primera meitat segle VII',601,650,1),(73,'primer quart segle VII',601,625,1),(74,'segon quart segle VII',626,650,1),(75,'segona meitat segle VII',651,700,1),(76,'tercer quart segle VII',651,675,1),(77,'últim quart segle VII',676,700,1),(78,'segle VIII',701,800,1),(79,'primera meitat segle VIII',701,750,1),(80,'primer quart segle VIII',701,725,1),(81,'segon quart segle VIII',726,750,1),(82,'segona meitat segle VIII',751,800,1),(83,'tercer quart segle VIII',751,775,1),(84,'últim quart segle VIII',776,800,1),(85,'segle IX',801,900,1),(86,'primera meitat segle IX',801,850,1),(87,'primer quart segle IX',801,825,1),(88,'segon quart segle IX',826,850,1),(89,'segona meitat segle IX',851,900,1),(90,'tercer quart segle IX',851,875,1),(91,'últim quart segle IX',876,900,1),(92,'segle X',901,1000,1),(93,'primera meitat segle X',901,950,1),(94,'primer quart segle X',901,925,1),(95,'segon quart segle X',926,950,1),(96,'segona meitat segle X',951,1000,1),(97,'tercer quart segle X',951,975,1),(98,'últim quart segle X',976,1000,1),(99,'segle XI',1001,1100,1),(100,'primera meitat segle XI',1001,1050,1),(101,'primer quart segle XI',1001,1025,1),(102,'segon quart segle XI',1026,1050,1),(103,'segona meitat segle XI',1051,1100,1),(104,'tercer quart segle XI',1051,1075,1),(105,'últim quart segle XI',1076,1100,1),(106,'segle XII',1101,1200,1),(107,'primera meitat segle XII',1101,1150,1),(108,'primer quart segle XII',1101,1125,1),(109,'segon quart segle XII',1126,1150,1),(110,'segona meitat segle XII',1151,1200,1),(111,'tercer quart segle XII',1151,1175,1),(112,'últim quart segle XII',1176,1200,1),(113,'segle XIII',1201,1300,1),(114,'primera meitat segle XIII',1201,1250,1),(115,'primer quart segle XIII',1201,1225,1),(116,'segon quart segle XIII',1226,1250,1),(117,'segona meitat segle XIII',1251,1300,1),(118,'tercer quart segle XIII',1251,1275,1),(119,'últim quart segle XIII',1276,1300,1),(120,'segle XIV',1301,1400,1),(121,'primera meitat segle XIV',1301,1350,1),(122,'primer quart segle XIV',1301,1325,1),(123,'segon quart segle XIV',1326,1350,1),(242,'segona meitat segle XIV',1351,1400,1),(243,'tercer quart segle XIV',1351,1375,1),(244,'últim quart segle XIV',1376,1400,1),(245,'segle XV',1401,1500,1),(246,'primera meitat segle XV',1401,1550,1),(247,'primer quart segle XV',1401,1425,1),(248,'segon quart segle XV',1426,1450,1),(249,'segona meitat segle XV',1451,1500,1),(250,'tercer quart segle XV',1451,1475,1),(251,'últim quart segle XV',1476,1500,1),(252,'segle XVI',1501,1600,1),(253,'primera meitat segle XVI',1501,1550,1),(254,'primer quart segle XVI',1501,1525,1),(255,'segon quart segle XVI',1526,1550,1),(256,'segona meitat segle XVI',1551,1600,1),(257,'tercer quart segle XVI',1551,1575,1),(258,'últim quart segle XVI',1576,1600,1),(259,'segle XVII',1601,1700,1),(260,'primera meitat segle XVII',1601,1650,1),(261,'primer quart segle XVII',1601,1625,1),(262,'segon quart segle XVII',1626,1650,1),(263,'segona meitat segle XVII',1651,1700,1),(264,'tercer quart segle XVII',1651,1675,1),(265,'últim quart segle XVII',1676,1700,1),(266,'segle XVIII',1701,1800,1),(267,'primera meitat segle XVIII',1701,1750,1),(268,'primer quart segle XVIII',1701,1725,1),(269,'segon quart segle XVIII',1726,1750,1),(270,'segona meitat segle XVIII',1751,1800,1),(271,'tercer quart segle XVIII',1751,1775,1),(272,'últim quart segle XVIII',1776,1800,1),(273,'segle XIX',1801,1900,1),(274,'primera meitat segle XIX',1801,1850,1),(275,'primer quart segle XIX',1801,1825,1),(276,'dècada de 1800',1801,1810,1),(277,'dècada de 1810',1811,1820,1),(278,'dècada de 1820',1821,1830,1),(279,'segon quart segle XIX',1826,1850,1),(280,'dècada de 1830',1831,1840,1),(281,'dècada de 1840',1841,1850,1),(282,'segona meitat segle XIX',1851,1900,1),(283,'tercer quart segle XIX',1851,1875,1),(284,'dècada de 1850',1851,1860,1),(285,'dècada de 1860',1861,1870,1),(286,'dècada de 1870',1871,1880,1),(287,'últim quart segle XIX',1876,1900,1),(288,'dècada de 1880',1881,1890,1),(289,'dècada de 1890',1891,1900,1),(290,'segle XX',1901,2000,1),(291,'primera meitat segle XX',1901,1950,1),(292,'primer quart segle XX',1901,1925,1),(293,'dècada de 1900',1901,1910,1),(294,'dècada de 1910',1911,1920,1),(295,'dècada de 1920 i 1930',1921,1940,1),(296,'dècada de 1920',1921,1930,1),(297,'segon quart segle XX',1926,1950,1),(298,'dècada de 1930 i 1940',1931,1950,1),(299,'dècada de 1930',1931,1940,1),(300,'dècada de 1940',1941,1950,1),(301,'segona meitat segle XX',1951,2000,1),(302,'tercer quart segle XX',1951,1975,1),(303,'dècada de 1950',1951,1960,1),(304,'dècada de 1960',1961,1970,1),(305,'dècada de 1970',1971,1980,1),(306,'últim quart segle XX',1976,2000,1),(307,'dècada de 1980',1981,1990,1),(308,'dècada de 1990',1991,2000,1),(309,'segle XXI',2001,2100,1),(310,'primera meitat segle XXI',2001,2050,1),(311,'primer quart segle XXI',2001,2025,1),(312,'segon quart segle XXI',2026,2050,1),(313,'abans',NULL,NULL,1),(314,'circa',NULL,NULL,1),(315,'posterior',NULL,NULL,1),(316,'precís',NULL,NULL,1),(317,'paleolític',-3000000,-9000,1),(318,'paleolític inferior',-3000000,-120000,1),(319,'paleolític inferior arcaic',-3000000,-600000,1),(320,'paleolític inferior peces evolucionades',-599999,-120000,1),(321,'paleolític inferior-mig indiferenciat',-119999,-50000,1),(322,'paleolític mig',-89999,-33000,1),(323,'paleolític superior',-22999,-9000,1),(324,'paleolític-epipaleolític',-10999,-7000,1),(325,'epipaleolític',-8999,-5000,1),(326,'neolític',-5499,-2200,1),(327,'neolític antic',-5499,-3500,1),(328,'neolític antic cardial',-5499,-4000,1),(329,'neolític antic postcardial',-3999,-3500,1),(330,'neolític mig-recent',-3499,-2500,1),(331,'neolític final',-2499,-2000,1),(332,'calcolític',-2199,-1800,1),(333,'bronze',-1799,-650,1),(334,'bronze antic',-1799,-1500,1),(335,'bronze mig',-1499,-1200,1),(336,'bronze final',-1199,-650,1),(337,'ferro-ibèric-colonitzacions',-649,50,1),(338,'ferro-ibèric antic',-649,-450,1),(339,'ferro-ibèric ple',-449,-200,1),(340,'romà',-218,476,1),(341,'romà república',-218,-50,1),(342,'ferro-ibèric final',-199,-50,1),(343,'romà August',-27,14,1),(344,'romà alt imperi',14,192,1),(345,'romà segle III',192,284,1),(346,'romà baix imperi',284,476,1),(347,'medieval',400,1492,1),(348,'medieval domini visigòtic',401,715,1),(349,'medieval ocupació i domini musulmà',715,799,1),(350,'medieval món islàmic',800,1150,1),(351,'medieval Catalunya vella sota Carolingis',800,988,1),(352,'medieval món islàmic Emirat',800,899,1),(353,'medieval món islàmic Califat',900,1015,1),(354,'medieval comptes de Barcelona',988,1150,1),(355,'medieval món islàmic Taifes',1016,1150,1),(356,'medieval consolidació Corona d\'Aragó',1150,1230,1),(357,'medieval baixa edat mitjana',1230,1492,1),(358,'modern',1492,1789,1),(359,'contemporani',1798,NULL,1);
/*!40000 ALTER TABLE `datations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entry`
--

DROP TABLE IF EXISTS `entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entry` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entry`
--

LOCK TABLES `entry` WRITE;
/*!40000 ALTER TABLE `entry` DISABLE KEYS */;
INSERT INTO `entry` VALUES (1,'cessio',1),(2,'comodat',1),(3,'compra',1),(4,'dació',1),(5,'desconeguda',1),(6,'dipòsit',1),(7,'donació',1),(8,'entrega obligatòria',1),(9,'excavació',1),(10,'expropiació',1),(11,'herència',1),(12,'intercanvi',1),(13,'llegat',1),(14,'ocupació',1),(15,'ofrena',1),(16,'permuta',1),(17,'premi',1),(18,'propietat directa',1),(19,'recol.lecció',1),(20,'recuperació',1),(22,'successió interadministrativa',1),(28,'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',1),(29,'dadadad',1);
/*!40000 ALTER TABLE `entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expositions`
--

DROP TABLE IF EXISTS `expositions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expositions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `expositionlocation` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `expositiontype` int DEFAULT NULL,
  `start_date` date NOT NULL DEFAULT (curdate()),
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_expositions_expositiontypes` (`expositiontype`),
  CONSTRAINT `FK_expositions_expositiontypes` FOREIGN KEY (`expositiontype`) REFERENCES `expositiontypes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expositions`
--

LOCK TABLES `expositions` WRITE;
/*!40000 ALTER TABLE `expositions` DISABLE KEYS */;
INSERT INTO `expositions` VALUES (1,'Prueba','en algun lugar',1,'2024-10-18','2024-11-18'),(2,'Prueba2','en algun sitio',2,'2024-10-21','2024-10-24'),(23,'caducada','caduc',1,'2024-10-20','2024-10-21');
/*!40000 ALTER TABLE `expositions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expositiontypes`
--

DROP TABLE IF EXISTS `expositiontypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expositiontypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expositiontypes`
--

LOCK TABLES `expositiontypes` WRITE;
/*!40000 ALTER TABLE `expositiontypes` DISABLE KEYS */;
INSERT INTO `expositiontypes` VALUES (1,'Aliena',1),(2,'Propia',1);
/*!40000 ALTER TABLE `expositiontypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genericclassifications`
--

DROP TABLE IF EXISTS `genericclassifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `genericclassifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genericclassifications`
--

LOCK TABLES `genericclassifications` WRITE;
/*!40000 ALTER TABLE `genericclassifications` DISABLE KEYS */;
INSERT INTO `genericclassifications` VALUES (1,'Clasificacion Champions LEague',1);
/*!40000 ALTER TABLE `genericclassifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `URL` text NOT NULL,
  `artwork` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Images_Artwork` (`artwork`) USING BTREE,
  CONSTRAINT `FK_Images_Artwork` FOREIGN KEY (`artwork`) REFERENCES `artworks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (1,'assets/img/example3.jpg',98),(2,'assets/img/example5.jpg',99),(3,'assets/img/example3.jpg',100),(4,'assets/img/example3.jpg',101),(5,'assets/img/example3.jpg',102),(6,'assets/img/example3.jpg',103),(7,'assets/img/example3.jpg',104),(8,'assets/img/example3.jpg',105),(9,'assets/img/example3.jpg',106),(10,'assets/img/example3.jpg',107),(11,'assets/img/example3.jpg',108),(12,'assets/img/example5.jpg',109),(13,'assets/img/example3.jpg',110),(14,'assets/img/example3.jpg',111),(15,'assets/img/example3.jpg',112),(16,'assets/img/example3.jpg',113),(17,'assets/img/example3.jpg',114),(18,'assets/img/example3.jpg',115),(19,'assets/img/example3.jpg',116),(20,'assets/img/example3.jpg',117),(21,'assets/img/example3.jpg',118),(22,'assets/img/example3.jpg',119),(23,'assets/img/example3.jpg',120),(24,'assets/img/example3.jpg',121),(25,'assets/img/example3.jpg',122),(26,'assets/img/example3.jpg',123),(27,'assets/img/example1.jpg',124),(28,'assets/img/example3.jpg',125),(29,'assets/img/example3.jpg',126),(30,'assets/img/example3.jpg',127),(31,'assets/img/example3.jpg',128),(32,'assets/img/example3.jpg',129),(33,'assets/img/example5.jpg',130),(34,'assets/img/example3.jpg',131),(35,'assets/img/example3.jpg',132),(36,'assets/img/example3.jpg',133),(37,'assets/img/example3.jpg',134),(38,'assets/img/example3.jpg',135),(39,'assets/img/example3.jpg',136),(40,'assets/img/example5.jpg',144);
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `parent` int DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Location_Location` (`parent`) USING BTREE,
  CONSTRAINT `FK_Location_Location` FOREIGN KEY (`parent`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (10,'Edifici principal',NULL),(11,'Planta 1',10),(12,'Planta 2',10),(13,'Planta 3',10),(16,'Sala 1',11),(17,'Sala 2',11),(18,'Sala 3',12),(19,'Sala 4',12),(20,'Sala 5',12),(21,'Sala 6',13),(22,'Sala 7',13),(23,'Sala 8',13),(26,'siuu',NULL),(27,'aa',NULL),(28,'ed',NULL),(29,'dfhdhg',NULL),(30,'P',NULL),(31,'Prueba3',NULL),(32,'sdfgsdfgsfgdfgdfs',NULL);
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materialgettycodes`
--

DROP TABLE IF EXISTS `materialgettycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materialgettycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materialgettycodes`
--

LOCK TABLES `materialgettycodes` WRITE;
/*!40000 ALTER TABLE `materialgettycodes` DISABLE KEYS */;
INSERT INTO `materialgettycodes` VALUES (1,'08313',1);
/*!40000 ALTER TABLE `materialgettycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materials` (
  `text` varchar(200) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materials`
--

LOCK TABLES `materials` WRITE;
/*!40000 ALTER TABLE `materials` DISABLE KEYS */;
INSERT INTO `materials` VALUES ('material de ejemplo',1,1);
/*!40000 ALTER TABLE `materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movements`
--

DROP TABLE IF EXISTS `movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `reason` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `artwork` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Movements_Artwork` (`artwork`) USING BTREE,
  CONSTRAINT `FK_Movements_Artwork` FOREIGN KEY (`artwork`) REFERENCES `artworks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movements`
--

LOCK TABLES `movements` WRITE;
/*!40000 ALTER TABLE `movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restorations`
--

DROP TABLE IF EXISTS `restorations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restorations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `reason` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `artwork` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_Restoration_Artwork` (`artwork`) USING BTREE,
  CONSTRAINT `FK_Restoration_Artwork` FOREIGN KEY (`artwork`) REFERENCES `artworks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restorations`
--

LOCK TABLES `restorations` WRITE;
/*!40000 ALTER TABLE `restorations` DISABLE KEYS */;
/*!40000 ALTER TABLE `restorations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tecniquegettycodes`
--

DROP TABLE IF EXISTS `tecniquegettycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tecniquegettycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tecniquegettycodes`
--

LOCK TABLES `tecniquegettycodes` WRITE;
/*!40000 ALTER TABLE `tecniquegettycodes` DISABLE KEYS */;
INSERT INTO `tecniquegettycodes` VALUES (1,'2409580',1);
/*!40000 ALTER TABLE `tecniquegettycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tecniques`
--

DROP TABLE IF EXISTS `tecniques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tecniques` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` varchar(200) NOT NULL DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tecniques`
--

LOCK TABLES `tecniques` WRITE;
/*!40000 ALTER TABLE `tecniques` DISABLE KEYS */;
INSERT INTO `tecniques` VALUES (1,'Tecnica destornillador',1);
/*!40000 ALTER TABLE `tecniques` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `last_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `email` varchar(180) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` enum('admin','tecnic','convidat') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `profile_img` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'assets/img/defaultprofile.png',
  `creation_date` timestamp NULL DEFAULT (now()),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin','Carla','Pérez Camacho','admin@admin.com','admin','assets/img/adminprofile.png','2024-10-06 15:49:39'),(3,'tecnic','tecnic','Juan-Carlos','Martínez','tecnic@tecnic.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(4,'convidat','convidat','Convidat','','convidat@convidat.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(55,'CarlosG','password123','Carlos','Garcia','carlos.garcia@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(56,'MariaL','password123','Maria','Lopez','maria.lopez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(57,'JuanM','password123','Juan','Martinez','juan.martinez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(58,'LuisH','password123','Luis','Hernandez','luis.hernandez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(59,'AnaG','password123','Ana','Gonzalez','ana.gonzalez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(60,'PabloD','password123','Pablo','Diaz','pablo.diaz@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(61,'SaraP','password123','Sara','Perez','sara.perez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(62,'JavierS','password123','Javier','Sanchez','javier.sanchez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(63,'CarmenR','password123','Carmen','Ramirez','carmen.ramirez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(64,'AlbertoF','password123','Alberto','Flores','alberto.flores@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(65,'EvaT','password123','Eva','Torres','eva.torres@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(66,'VictorR','password123','Victor','Rivera','victor.rivera@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(67,'DanielaJ','password123','Daniela','Jimenez','daniela.jimenez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(68,'FranciscoM','password123','Francisco','Morales','francisco.morales@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(69,'ClaraO','password123','Clara','Ortiz','clara.ortiz@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(70,'RaulC','password123','Raul','Castillo','raul.castillo@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(71,'PatriciaG','password123','Patricia','Gil','patricia.gil@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(72,'GabrielR','password123','Gabriel','Ramos','gabriel.ramos@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(73,'TeresaF','password123','Teresa','Fernandez','teresa.fernandez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(74,'AdrianR','password123','Adrian','Ruiz','adrian.ruiz@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(75,'LorenaM','password123','Lorena','Mendoza','lorena.mendoza@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(76,'SergioV','password123','Sergio','Vega','sergio.vega@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(77,'AliciaS','password123','Alicia','Santos','alicia.santos@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(79,'IsabelR','password123','Isabel','Romero','isabel.romero@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(80,'DiegoA','password123','Diego','Acosta','diego.acosta@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(81,'JuliaF','password123','Julia','Ferrer','julia.ferrer@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(82,'JorgeN','password123','Jorge','Navarro','jorge.navarro@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(83,'ElenaR','password123','Elena','Reyes','elena.reyes@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(84,'AlfredoP','password123','Alfredo','Pena','alfredo.pena@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(85,'CristinaH','password123','Cristina','Herrera','cristina.herrera@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(86,'RamonG','password123','Ramon','Garcia','ramon.garcia@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(87,'MartaG','password123','Marta','Gutierrez','marta.gutierrez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(88,'RicardoC','password123','Ricardo','Cruz','ricardo.cruz@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(89,'SilviaL','password123','Silvia','Lopez','silvia.lopez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(90,'PedroS','password123','Pedro','Sanchez','pedro.sanchez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(91,'BeatrizM','password123','Beatriz','Moreno','beatriz.moreno@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(92,'EmilioM','password123','Emilio','Martinez','emilio.martinez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(93,'SusanaM','password123','Susana','Molina','susana.molina@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(94,'EduardoP','password123','Eduardo','Perez','eduardo.perez@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(96,'AntonioO','password123','Antonio','Ortega','antonio.ortega@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(97,'GloriaD','password123','Gloria','Delgado','gloria.delgado@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(98,'LuisM','password123','Luis','Mendez','luis.mendez@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(99,'RosaV','password123','Rosa','Vazquez','rosa.vazquez@example.com','convidat','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(100,'OscarC','password123','Oscar','Cano','oscar.cano@example.com','admin','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(101,'MonicaR','password123','Monica ','Rios','monica.rios@example.com','tecnic','assets/img/defaultprofile.png','2024-10-06 15:49:39'),(182,'aasa','fsgs','gshf','hdfjhdj','djdj@gmail.com','admin','assets/img/defaultprofile.png','2024-10-21 07:48:39'),(187,'fasdfasdfadfadsf','fadsfasdfasfsdf','fadsfasfdasdfasd','fadsfdafasfdaD','afafsdfafa@fads.a','admin','assets/img/Captura de pantalla de 2024-10-23 10-33-33.png','2024-10-23 08:36:09');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-25  8:18:43
